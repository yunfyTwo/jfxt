/**
 * AppApplication.java
 * Created at 2018年5月2日
 * Created by FPM0302
 * Copyright (C) 2014-2017 FNConn, All rights reserved.
 */
package com.fjt;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.fjt.core.annotation.ExcludeFromComponentScan;

/**
 * <p>ClassName: FoxconnGroupApplication</p>
 * <p>Description: 启动类入口</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年5月2日</p>
 */
@SpringBootApplication
@MapperScan("com.fjt.**.mapper")
@EnableTransactionManagement
@EnableCaching//加上这个注解是的支持缓存注解
@EnableDiscoveryClient //运行作为Eureka的客户端
@EnableFeignClients //启用Feign 声明式调用
@EnableCircuitBreaker //启用断路器
@ComponentScan(excludeFilters = {@ComponentScan.Filter(type = FilterType.ANNOTATION, value = ExcludeFromComponentScan.class)})
public class AppApplication extends SpringBootServletInitializer {
    /**
     * <p>Description: 入口类</p>
     * @param args 外部传入的参数
     */
    public static void main(String[] args) {
        SpringApplication.run(AppApplication.class, args);
    }
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(AppApplication.class);
    }
}

/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
