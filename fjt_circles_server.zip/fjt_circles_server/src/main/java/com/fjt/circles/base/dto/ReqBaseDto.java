/**
 * ReqBaseDto.java
 * Created at 2019年11月18日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.base.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>ClassName: ReqBaseDto</p>
 * <p>Description: 公共DTO</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月18日</p>
 */
@ApiModel("公共实体")
public class ReqBaseDto {
    
    /** 用户ID */
    @ApiModelProperty(value = "用户ID", required = true)
    private Long userId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月18日                     FPM0218        fnAPP19Q3001
 */
