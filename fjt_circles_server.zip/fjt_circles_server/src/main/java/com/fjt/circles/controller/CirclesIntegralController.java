/**
 * CirclesIntegralController.java
 * Created at 2019年11月19日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fjt.circles.domain.IntegralDateDomain;
import com.fjt.circles.enums.CommonError;
import com.fjt.circles.service.CirclesIntegralService;
import com.fjt.common.Constant;
import com.fjt.common.ResponseData;

/**
 * <p>ClassName: CirclesIntegralController</p>
 * <p>Description: 用户积分控制层</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月19日</p>
 */
@RestController
@RequestMapping("/integral")
@Api(tags = { "circlesIntegral" }, description = "用户积分接口")
public class CirclesIntegralController {
    
    /**
     * 用户积分接口
     */
    @Autowired
    private CirclesIntegralService circlesIntegralService;
    
    /**
     * <p>Description: 获取积分折线图</p>
     * @param request HttpServletRequest
     * @param userId 请求参数
     * @return 积分折线图
     */
    @GetMapping("/getIntegralDiscountChart")
    @ApiOperation(value = "获取积分折线图", httpMethod = "GET", notes = "获取积分折线图", response = ResponseData.class)
    public ResponseData getIntegralDiscountChart(HttpServletRequest request, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        List<IntegralDateDomain> list = circlesIntegralService.getIntegralDiscountChart(userId);
        responseData.setData(list);
        return responseData;
    }
    
    /**
     * <p>Description: 获取我的总积分</p>
     * @param request HttpServletRequest
     * @param userId 请求参数
     * @return 我的总积分
     */
    @GetMapping("/getMyTotalIntegral")
    @ApiOperation(value = "获取我的总积分", httpMethod = "GET", notes = "获取我的总积分", response = ResponseData.class)
    public ResponseData getMyTotalIntegral(HttpServletRequest request, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        Integer result = circlesIntegralService.getMyTotalIntegral(userId);
        responseData.setData(result);
        return responseData;
    }
    
    /**
     * <p>Description: 获取我贡献的总积分</p>
     * @param request HttpServletRequest
     * @param userId 请求参数
     * @return 我贡献的总积分
     */
    @GetMapping("/getMyContributeIntegral")
    @ApiOperation(value = "获取我贡献的总积分", httpMethod = "GET", notes = "获取我贡献的总积分", response = ResponseData.class)
    public ResponseData getMyContributeIntegral(HttpServletRequest request, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        Integer result = circlesIntegralService.getMyContributeIntegral(userId);
        responseData.setData(result);
        return responseData;
    }
    
    /**
     * <p>Description: 检查用户ID</p>
     * @param userId 用户ID
     * @return 检查结果
     */
    private String checkUserId(Long userId) {
        if (userId == null) {
            return CommonError.APP_PARAMETER_ERROR.getErrorTitle();
        }
        if (userId < 1) {
            return CommonError.APP_PARAMETER_NOT_SUPPORT.getErrorTitle();
        }
        return Constant.BLANK_STRING;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月19日                     FPM0218        fnAPP19Q3001
 */
