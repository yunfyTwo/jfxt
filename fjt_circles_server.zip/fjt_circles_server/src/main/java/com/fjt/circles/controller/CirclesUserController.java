/**
 * CirclesUserController.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fjt.circles.domain.MyUnderPersonNumDomain;
import com.fjt.circles.domain.PurSupManagerDomain;
import com.fjt.circles.domain.UserInfoDomain;
import com.fjt.circles.dto.ReqConfirmUserTypeDto;
import com.fjt.circles.dto.ReqUserRegDto;
import com.fjt.circles.dto.ReqUserSupplementInfoDto;
import com.fjt.circles.dto.ReqWechatDto;
import com.fjt.circles.enums.CommonError;
import com.fjt.circles.model.CirclesUser;
import com.fjt.circles.service.CirclesUserService;
import com.fjt.common.Constant;
import com.fjt.common.PageList;
import com.fjt.common.ResponseData;
import com.fjt.common.StringUtil;

/**
 * <p>ClassName: CirclesUserController</p>
 * <p>Description: 用户信息接口</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */
@RestController
@RequestMapping("/user")
@Api(tags = { "circlesUser" }, description = "用户信息接口")
public class CirclesUserController {
    
    /**
     * 圈子用户接口
     */
    @Autowired
    private CirclesUserService circlesUserService;
    
    /**
     * <p>Description: 获取当前用户ID密文</p>
     * @param request HttpServletRequest
     * @param userId 用户ID
     * @return 用户ID密文
     */
    @GetMapping("/getCurrentUserIdCiphertext")
    @ApiOperation(value = "获取当前用户ID密文", httpMethod = "GET", notes = "获取当前用户ID密文", response = ResponseData.class)
    public ResponseData getCurrentUserIdCiphertext(HttpServletRequest request, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        responseData.setData(StringUtil.encode(String.valueOf(userId)));
        return responseData;
    }
    
    /**
     * <p>Description: 通过用户ID获取用户信息</p>
     * @param request HttpServletRequest
     * @param userId 用户ID
     * @return 用户信息
     */
    @GetMapping("/getCirclesUserById")
    @ApiOperation(value = "通过用户ID获取用户信息", httpMethod = "GET", notes = "通过用户ID获取用户信息", response = ResponseData.class)
    public ResponseData getCirclesUserById(HttpServletRequest request, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        UserInfoDomain userInfoDomain = circlesUserService.getCirclesUserById(userId);
        responseData.setData(userInfoDomain);
        return responseData;
    }
    
    /**
     * <p>Description: 通过OPENID获取用户信息</p>
     * @param request HttpServletRequest
     * @param openId OPENID
     * @return 用户信息
     */
    @GetMapping("/getCirclesUserByOpenId")
    @ApiOperation(value = "通过OPENID获取用户信息", httpMethod = "GET", notes = "通过OPENID获取用户信息", response = ResponseData.class)
    public ResponseData getCirclesUserByOpenId(HttpServletRequest request, String openId) {
        ResponseData responseData = new ResponseData();
        if (openId == null) {
            responseData.setCode(-1);
            responseData.setMessage(CommonError.APP_PARAMETER_ERROR.getErrorTitle());
            return responseData;
        }
        Map<String, Object> map = circlesUserService.getCirclesUserMapByOpenId(openId);
        responseData.setData(map);
        return responseData;
    }
    
    /**
     * <p>Description: 跳转至圈子营销小程序</p>
     * @param request HttpServletRequest
     * @param dto 请求参数
     * @return 用户信息
     */
    @PostMapping("/jumpToCirclesByJsCode")
    @ApiOperation(value = "跳转至圈子营销小程序", httpMethod = "POST", notes = "跳转至圈子营销小程序", response = ResponseData.class)
    public ResponseData jumpToCirclesByJsCode(HttpServletRequest request, @RequestBody ReqUserRegDto dto) {
        ResponseData responseData = new ResponseData();
        String jsCode = dto.getJsCode();
        if (StringUtil.isEmpty(jsCode)) {
            responseData.setCode(-1);
            responseData.setMessage(CommonError.APP_PARAMETER_ERROR.getErrorTitle());
            return responseData;
        } 
        Map<String, Object> map = circlesUserService.saveUser(dto);
        String errorMsg = (String) map.get("errorMsg");
        if (StringUtil.isNotEmpty(errorMsg)) {
            responseData.setCode(-1);
            responseData.setMessage(errorMsg);
            return responseData;
        }
        responseData.setData(map);
        return responseData;
    }
    
    /**
     * <p>Description: 保存用户补充信息</p>
     * @param request HttpServletRequest
     * @param dto 参数
     * @return 保存结果
     */
    @PostMapping("/saveUserSupplementInfoInfo")
    @ApiOperation(value = "保存用户补充信息", httpMethod = "POST", notes = "保存用户补充信息", response = ResponseData.class)
    public ResponseData saveUserSupplementInfoInfo(HttpServletRequest request, @RequestBody ReqWechatDto dto) {
        ResponseData responseData = new ResponseData();
        if (dto == null || dto.getUserId() == null) {
            responseData.setCode(-1);
            responseData.setMessage(CommonError.APP_PARAMETER_ERROR.getErrorTitle());
            return responseData;
        }
        if (dto.getApplyUserType() != 1 && dto.getApplyUserType() != 0 && dto.getApplyUserType() != 2) {
            responseData.setCode(-1);
            responseData.setMessage(CommonError.APP_PARAMETER_NOT_SUPPORT.getErrorTitle());
            return responseData;
        }
        String result = circlesUserService.saveUserSupplementInfoInfo(dto);
        if (!Constant.YES.equals(result)) {
            responseData.setCode(-1);
            responseData.setMessage(result);
        } else {
            UserInfoDomain userInfoDomain = circlesUserService.getCirclesUserById(dto.getUserId());
            responseData.setData(userInfoDomain);
        }
        return responseData;
    }
    
    /**
     * <p>Description: 获取我参与邀请的供应商</p>
     * @param request HttpServletRequest
     * @param currentPage 当前页
     * @param pageSize 页面大小
     * @param userId 用户ID
     * @return 结果
     */
    @GetMapping("/getMyInvitedSupplier")
    @ApiOperation(value = "获取我参与邀请的供应商", httpMethod = "GET", notes = "获取我参与邀请的供应商", response = ResponseData.class)
    public ResponseData getMyInvitedSupplier(HttpServletRequest request, int currentPage, int pageSize, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        currentPage = currentPage <= 0 ? 1 : currentPage;
        pageSize = pageSize <= 0 ? 1 : pageSize;
        PageList pageList = circlesUserService.getMyInvitedSupplier(userId, currentPage, pageSize);
        responseData.setCode(0);
        responseData.setData(pageList);
        return responseData;
    }
    
    
    /**
     * <p>Description: 获取我的下线人数</p>
     * @param request HttpServletRequest
     * @param userId 用户ID
     * @return 结果
     */
    @GetMapping("/getMyUnderUserCountByUserId")
    @ApiOperation(value = "获取我的下线人数统计", httpMethod = "GET", notes = "获取我的下线人数", response = ResponseData.class)
    public ResponseData getMyUnderUserCountByUserId(HttpServletRequest request, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        MyUnderPersonNumDomain domain = circlesUserService.getMyUnderUserCountByParentId(userId);
        responseData.setCode(0);
        responseData.setData(domain);
        return responseData;
    }
    
    /**
     * <p>Description: 获取我参与邀请的供应商</p>
     * @param request HttpServletRequest
     * @param currentPage 当前页
     * @param pageSize 页面大小
     * @param userId 用户ID
     * @return 结果
     */
    @GetMapping("/getMyUnderUserByUserId")
    @ApiOperation(value = "获取我的下线人员信息", httpMethod = "GET", notes = "获取我的下线人员信息", response = ResponseData.class)
    public ResponseData getMyUnderUserByUserId(HttpServletRequest request, int currentPage, int pageSize, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        currentPage = currentPage <= 0 ? 1 : currentPage;
        pageSize = pageSize <= 0 ? 1 : pageSize;
        PageList pageList =  circlesUserService.getMyUnderUserByParentId(userId, currentPage, pageSize);
        responseData.setCode(0);
        responseData.setData(pageList);
        return responseData;
    }
    
    /**
     * <p>Description: 确认子用户类型</p>
     * @param request HttpServletRequest
     * @param dto 参数
     * @return 保存结果
     */
    @PostMapping("/confirmChildUserType")
    @ApiOperation(value = "确认子用户类型", httpMethod = "POST", notes = "确认子用户类型", response = ResponseData.class)
    public ResponseData confirmChildUserType(HttpServletRequest request, @RequestBody ReqConfirmUserTypeDto dto) {
        ResponseData responseData = new ResponseData();
        if (dto == null || dto.getUserId() == null || dto.getChildUserId() == null || dto.getActualUserType() == null) {
            responseData.setCode(-1);
            responseData.setMessage(CommonError.APP_PARAMETER_ERROR.getErrorTitle());
            return responseData;
        }
        if (dto.getActualUserType() != 1 && dto.getActualUserType() != 0) {
            responseData.setCode(-1);
            responseData.setMessage(CommonError.APP_PARAMETER_NOT_SUPPORT.getErrorTitle());
            return responseData;
        }
        CirclesUser circlesUser = new CirclesUser();
        circlesUser.setId(dto.getChildUserId());
        circlesUser.setActualUserType(dto.getActualUserType());
        circlesUser.setLstUpdUser(String.valueOf(dto.getUserId()));
        circlesUserService.updateCirclesUser(circlesUser);
        return responseData;
    }
    
    /**
     * <p>Description: 修改用户名片</p>
     * @param request HttpServletRequest
     * @param dto 参数
     * @return 修改结果
     */
    @PostMapping("/updateUserCard")
    @ApiOperation(value = "修改用户名片", httpMethod = "POST", notes = "修改用户名片", response = ResponseData.class)
    public ResponseData updateUserCard(HttpServletRequest request, @RequestBody ReqUserSupplementInfoDto dto) {
        ResponseData responseData = new ResponseData();
        if (dto == null || dto.getUserId() == null || StringUtil.isEmpty(dto.getCardFileName())) {
            responseData.setCode(-1);
            responseData.setMessage(CommonError.APP_PARAMETER_ERROR.getErrorTitle());
            return responseData;
        }
        String result = circlesUserService.updateUserSupplementInfoInfo(dto);
        if (!Constant.YES.equals(result)) {
            responseData.setCode(-1);
            responseData.setMessage(result);
        } else {
            UserInfoDomain userInfoDomain = circlesUserService.getCirclesUserById(dto.getUserId());
            responseData.setData(userInfoDomain);
        }
        return responseData;
    }
    
    /**
     * <p>Description: 获取采购商和客户经理信息</p>
     * @param request HttpServletRequest
     * @param userId 用户ID
     * @return 采购商和客户经理信息
     */
    @GetMapping("/getPurAndManagerInfo")
    @ApiOperation(value = "获取采购商和客户经理信息", httpMethod = "GET", notes = "获取采购商和客户经理信息", response = ResponseData.class)
    public ResponseData getPurAndManagerInfo(HttpServletRequest request, Long userId) {
        ResponseData responseData = new ResponseData();
        String message = checkUserId(userId);
        if (!Constant.BLANK_STRING.equals(message)) {
            responseData.setCode(-1);
            responseData.setMessage(message);
            return responseData;
        }
        PurSupManagerDomain purSupManagerDomain = circlesUserService.getPurAndManagerInfo(userId);
        responseData.setData(purSupManagerDomain);
        return responseData;
    }
    
    /**
     * <p>Description: 检查用户ID</p>
     * @param userId 用户ID
     * @return 检查结果
     */
    private String checkUserId(Long userId) {
        if (userId == null) {
            return CommonError.APP_PARAMETER_ERROR.getErrorTitle();
        }
        if (userId < 1) {
            return CommonError.APP_PARAMETER_NOT_SUPPORT.getErrorTitle();
        }
        return Constant.BLANK_STRING;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
