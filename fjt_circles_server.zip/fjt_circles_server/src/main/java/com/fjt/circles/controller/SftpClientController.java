/**
 * SftpClientController.java
 * Created at 2019年11月13日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.controller;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fjt.core.utils.SftpClientUtils;


/**
 * <p>ClassName: SftpClientController</p>
 * <p>Description: SFTP控制层</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月13日</p>
 */
@RestController
@RequestMapping("/file")
public class SftpClientController {
    
    /** 日志 */
    private static final Logger LOGGER = LoggerFactory.getLogger("SftpClientController");
    
    /** UTF8 */
    private static final String UTF8 = "UTF-8";
    
    /**
     * <p>Description: 读取文件</p>
     * @param type 类型
     * @param id 编号 
     * @param time 时间
     * @param name 文件名
     * @param suffix 后缀名
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @throws IOException IO异常
     */
    @GetMapping({ "/{type}/{id}/{time}/{name}.{suffix}"})
    public void getFile(@PathVariable String type, @PathVariable String id, @PathVariable String time, 
            @PathVariable String name, @PathVariable String suffix, HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        name = URLDecoder.decode(name, UTF8);
        byte[] buffer = SftpClientUtils.access(type + File.separator + id + File.separator + time + File.separator + name + "." + suffix);
        if (buffer == null) {
            return;
        }
        LOGGER.info("type:" + type + ", name:" + name + ", suffix:" + suffix);
        response.setCharacterEncoding(UTF8);
        switch (suffix.toLowerCase()) {
            case "jpg":
            case "jpeg":
                response.setContentType("image/jpeg");
                break;
            case "png":
                response.setContentType("image/png");
                break;
            case "bmp":
                response.setContentType("image/bmp");
                break;
            default:
                response.setContentType("application/*");
                break;
        }
        OutputStream stream = response.getOutputStream();
        stream.write(buffer);
        stream.flush();
        stream.close();
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月13日                     FPM0218        fnAPP19Q3001
 */
