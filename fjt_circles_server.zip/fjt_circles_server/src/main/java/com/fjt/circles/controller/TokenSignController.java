/**
 * TokenSignController.java
 * Created at 2019年10月13日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fjt.common.HttpClientUtil;
import com.fjt.common.ResponseData;
import com.fjt.common.StringUtil;
import com.fjt.core.token.TokenComponent;

/**
 * <p>ClassName: TokenSignController</p>
 * <p>Description: 获取token信息</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月13日</p>
 */
@RestController
@RequestMapping("/sign")
@Api(tags = {"token"}, description = "获取token信息")
public class TokenSignController {
    /**
     * TokenSignService
     */
    @Autowired
    private TokenComponent tokenComponent;

    /**
     * <p>Description: 获取token</p>
     * @param appkey appkey
     * @param appSecutity appSecutity
     * @param request HttpServletRequest
     * @return ResponseData
     */
    @PostMapping("/getToken")
    @ApiOperation(value = "获取token", httpMethod = "POST", notes = "获取token")
    public ResponseData getToken(String appkey, String appSecutity, HttpServletRequest request) {
        ResponseData responseData = new ResponseData();
        String ip = HttpClientUtil.getIpAddr(request);
        String token = this.tokenComponent.getToken(appkey, appSecutity, ip);
        if (StringUtil.isEmpty(token)) {
            responseData.setCode(-1);
        } else {
            responseData.setData(token);
        }
        return responseData;
    }
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月13日                     FPM0218        fnAPP19Q3001
 */

