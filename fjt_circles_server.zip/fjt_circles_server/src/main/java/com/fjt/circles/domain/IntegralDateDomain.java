/**
 * IntegralDateDomain.java
 * Created at 2019年11月19日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.domain;

/**
 * <p>ClassName: IntegralDateDomain</p>
 * <p>Description: 时间和积分封装类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月19日</p>
 */
public class IntegralDateDomain {
    
    /** 创建时间 */
    private String createTime;
    /** 积分 */
    private int integral;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getIntegral() {
        return integral;
    }

    public void setIntegral(int integral) {
        this.integral = integral;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月19日                     FPM0218        fnAPP19Q3001
 */
