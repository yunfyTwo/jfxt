/**
 * MyUnderPersonInfoDomain.java
 * Created at 2019年11月20日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.domain;

/**
 * <p>ClassName: MyUnderPersonInfoDomain</p>
 * <p>Description: 我邀请的下线人员信息类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月20日</p>
 */
public class MyUnderPersonInfoDomain {
    
    /** 用户ID */ 
    private Long userId;
    /** 昵称 */
    private String nickName;
    /** 微信头像 */
    private String wechatImgPath;
    /** 申请用户类型*/
    private Integer applyUserType;
    /** 实际用户类型（null:未确认；0:确认为否；1:确认为是） */
    private Integer actualUserType;
    /** 贡献积分 */
    private int contributeIntegral;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getWechatImgPath() {
        return wechatImgPath;
    }

    public void setWechatImgPath(String wechatImgPath) {
        this.wechatImgPath = wechatImgPath;
    }

    public Integer getApplyUserType() {
        return applyUserType;
    }

    public void setApplyUserType(Integer applyUserType) {
        this.applyUserType = applyUserType;
    }

    public Integer getActualUserType() {
        return actualUserType;
    }

    public void setActualUserType(Integer actualUserType) {
        this.actualUserType = actualUserType;
    }

    public int getContributeIntegral() {
        return contributeIntegral;
    }

    public void setContributeIntegral(int contributeIntegral) {
        this.contributeIntegral = contributeIntegral;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月20日                     FPM0218        fnAPP19Q3001
 */
