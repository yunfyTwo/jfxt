/**
 * MyUnderPersonNumDomain.java
 * Created at 2019年11月18日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.domain;

/**
 * <p>ClassName: MyInviteeNumDomain</p>
 * <p>Description: 我邀请的下线数目类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月18日</p>
 */
public class MyUnderPersonNumDomain {
    
    /** 邀请总数*/
    private int inviteTotal;
    /** 已确认身份数量 */
    private int confirmCount;
    /** 未确认身份数量 */
    private int unConfirmCount;

    public int getInviteTotal() {
        return inviteTotal;
    }

    public void setInviteTotal(int inviteTotal) {
        this.inviteTotal = inviteTotal;
    }

    public int getConfirmCount() {
        return confirmCount;
    }

    public void setConfirmCount(int confirmCount) {
        this.confirmCount = confirmCount;
    }

    public int getUnConfirmCount() {
        return unConfirmCount;
    }

    public void setUnConfirmCount(int unConfirmCount) {
        this.unConfirmCount = unConfirmCount;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月18日                     FPM0218        fnAPP19Q3001
 */
