/**
 * PurSupDomain.java
 * Created at 2019年11月18日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.domain;

/**
 * <p>ClassName: PurSupDomain</p>
 * <p>Description: 采购商和供应商封装类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月18日</p>
 */
public class PurSupDomain {
    
    /** 采购商昵称 */
    private String purNickName;
    /** 采购商头像 */
    private String purWechatImgPath;
    /** 采购商类型 */ 
    private Integer purUserType;
    /** 供应商昵称 */
    private String supNickName;
    /** 供应商头像 */
    private String supWechatImgPath;
    /** 供应商类型 */ 
    private Integer supUserType;

    public String getPurNickName() {
        return purNickName;
    }

    public void setPurNickName(String purNickName) {
        this.purNickName = purNickName;
    }

    public String getPurWechatImgPath() {
        return purWechatImgPath;
    }

    public void setPurWechatImgPath(String purWechatImgPath) {
        this.purWechatImgPath = purWechatImgPath;
    }

    public Integer getPurUserType() {
        return purUserType;
    }

    public void setPurUserType(Integer purUserType) {
        this.purUserType = purUserType;
    }

    public String getSupNickName() {
        return supNickName;
    }

    public void setSupNickName(String supNickName) {
        this.supNickName = supNickName;
    }

    public String getSupWechatImgPath() {
        return supWechatImgPath;
    }

    public void setSupWechatImgPath(String supWechatImgPath) {
        this.supWechatImgPath = supWechatImgPath;
    }

    public Integer getSupUserType() {
        return supUserType;
    }

    public void setSupUserType(Integer supUserType) {
        this.supUserType = supUserType;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月18日                     FPM0218        fnAPP19Q3001
 */
