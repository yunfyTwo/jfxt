/**
 * PurSupManagerDomain.java
 * Created at 2019年11月20日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.domain;

/**
 * <p>ClassName: PurSupManagerDomain</p>
 * <p>Description: 采购商和客户经理信息封装类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月20日</p>
 */
public class PurSupManagerDomain {
    
    /** 供应商昵称 */
    private String supNickName;
    /** 供应商头像 */
    private String supWechatImgPath;
    /** 采购商昵称 */
    private String purNickName;
    /** 采购商头像 */
    private String purWechatImgPath;
    /** 客户经理微信昵称 */
    private String managerNickName;
    /** 客户经理微信头像路径 */
    private String managerWechatImgPath;
    /** 客户经理 名片路径*/
    private String managerBusinessCardPath;

    public String getSupNickName() {
        return supNickName;
    }

    public void setSupNickName(String supNickName) {
        this.supNickName = supNickName;
    }

    public String getSupWechatImgPath() {
        return supWechatImgPath;
    }

    public void setSupWechatImgPath(String supWechatImgPath) {
        this.supWechatImgPath = supWechatImgPath;
    }

    public String getPurNickName() {
        return purNickName;
    }

    public void setPurNickName(String purNickName) {
        this.purNickName = purNickName;
    }

    public String getPurWechatImgPath() {
        return purWechatImgPath;
    }

    public void setPurWechatImgPath(String purWechatImgPath) {
        this.purWechatImgPath = purWechatImgPath;
    }

    public String getManagerNickName() {
        return managerNickName;
    }

    public void setManagerNickName(String managerNickName) {
        this.managerNickName = managerNickName;
    }

    public String getManagerWechatImgPath() {
        return managerWechatImgPath;
    }

    public void setManagerWechatImgPath(String managerWechatImgPath) {
        this.managerWechatImgPath = managerWechatImgPath;
    }

    public String getManagerBusinessCardPath() {
        return managerBusinessCardPath;
    }

    public void setManagerBusinessCardPath(String managerBusinessCardPath) {
        this.managerBusinessCardPath = managerBusinessCardPath;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月20日                     FPM0218        fnAPP19Q3001
 */
