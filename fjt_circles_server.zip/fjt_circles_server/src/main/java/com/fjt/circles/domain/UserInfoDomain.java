/**
 * UserInfoDomain.java
 * Created at 2019年11月20日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.domain;

/**
 * <p>ClassName: UserInfoDomain</p>
 * <p>Description: 用户信息封装类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月20日</p>
 */
public class UserInfoDomain {

    /** 主键 */
    private Long userId;
    /** 邀请人ID */
    private Long parentUserId;
    /** 登录账号 */
    private String openId;
    /** 姓名 */
    private String userName;
    /** 职务 */
    private String job;
    /** 手机 */
    private String mobile;
    /** 邮箱 */
    private String email;
    /** 申请用户类型 */
    private Integer applyUserType;
    /** 实际用户类型（null:未确认；0:确认为否；1:确认为是） */
    private Integer actualUserType;
    /** 公司名称 */
    private String companyName;
    /** 用户等级（1:普通会员；2:黄金会员） */
    private Integer userLv;
    /** 昵称 */
    private String nickName;
    /** 微信头像 */
    private String wechatImgPath;
    /** 名片 */
    private String businessCardPath;
    /** 地址 */
    private String address;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getParentUserId() {
        return parentUserId;
    }

    public void setParentUserId(Long parentUserId) {
        this.parentUserId = parentUserId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getApplyUserType() {
        return applyUserType;
    }

    public void setApplyUserType(Integer applyUserType) {
        this.applyUserType = applyUserType;
    }

    public Integer getActualUserType() {
        return actualUserType;
    }

    public void setActualUserType(Integer actualUserType) {
        this.actualUserType = actualUserType;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getUserLv() {
        return userLv;
    }

    public void setUserLv(Integer userLv) {
        this.userLv = userLv;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getWechatImgPath() {
        return wechatImgPath;
    }

    public void setWechatImgPath(String wechatImgPath) {
        this.wechatImgPath = wechatImgPath;
    }

    public String getBusinessCardPath() {
        return businessCardPath;
    }

    public void setBusinessCardPath(String businessCardPath) {
        this.businessCardPath = businessCardPath;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月20日                     FPM0218        fnAPP19Q3001
 */
