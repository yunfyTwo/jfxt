/**
 * ReqConfirmUserTypeDto.java
 * Created at 2019年11月20日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import com.fjt.circles.base.dto.ReqBaseDto;

/**
 * <p>ClassName: ReqConfirmUserTypeDto</p>
 * <p>Description: 确认用户类型DTO</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月20日</p>
 */
@ApiModel("确认用户类型实体")
public class ReqConfirmUserTypeDto extends ReqBaseDto {
    
    /** 子用户ID */
    @ApiModelProperty(value = "子用户ID", required = true)
    private Long childUserId;
    
    /** 确认用户类型（0:确认为否；1:确认为是） */
    @ApiModelProperty(value = "确认用户类型（0:确认为否；1:确认为是）", required = true)
    private Integer actualUserType;

    public Long getChildUserId() {
        return childUserId;
    }

    public void setChildUserId(Long childUserId) {
        this.childUserId = childUserId;
    }

    public Integer getActualUserType() {
        return actualUserType;
    }

    public void setActualUserType(Integer actualUserType) {
        this.actualUserType = actualUserType;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月20日                     FPM0218        fnAPP19Q3001
 */
