/**
 * ReqUserRegDto.java
 * Created at 2019年11月19日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>ClassName: ReqUserRegDto</p>
 * <p>Description: 用户注册DTO</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月19日</p>
 */
@ApiModel("用户登录实体")
public class ReqUserRegDto {
    
    /** 邀请者ID */
    @ApiModelProperty(value = "邀请者ID", required = false)
    private String inviterId;
    
    /** JSCODE */
    @ApiModelProperty(value = "JSCODE", required = true)
    private String jsCode;

    public String getInviterId() {
        return inviterId;
    }

    public void setInviterId(String inviterId) {
        this.inviterId = inviterId;
    }

    public String getJsCode() {
        return jsCode;
    }

    public void setJsCode(String jsCode) {
        this.jsCode = jsCode;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月19日                     FPM0218        fnAPP19Q3001
 */
