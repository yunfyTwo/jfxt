/**
 * ReqUserSupplementInfoDto.java
 * Created at 2019年11月15日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.dto;

import com.fjt.circles.base.dto.ReqBaseDto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>ClassName: ReqUserSupplementInfoDto</p>
 * <p>Description: 用户补充信息实体</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月15日</p>
 */
@ApiModel("用户补充信息实体")
public class ReqUserSupplementInfoDto extends ReqBaseDto {
    
    /** 姓名 */
    @ApiModelProperty(value = "姓名", required = false)
    private String userName;
    
    /** 职务 */
    @ApiModelProperty(value = "职务", required = false)
    private String job;
    
    /** 手机号 */
    @ApiModelProperty(value = "手机号", required = false)
    private String mobile;
    
    /** 邮箱 */
    @ApiModelProperty(value = "邮箱", required = false)
    private String email;
    
    /** 公司名称 */
    @ApiModelProperty(value = "公司名称 ", required = false)
    private String companyName;

    /** 名片流 */
    @ApiModelProperty(value = "名片流", required = true)
    private byte[] cardFileByte;
    
    /** 名片名 */
    @ApiModelProperty(value = "名片名字", required = true)
    private String cardFileName;
    
    /** 地址 */
    @ApiModelProperty(value = "地址", required = false)
    private String address;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public byte[] getCardFileByte() {
        return cardFileByte;
    }

    public void setCardFileByte(byte[] cardFileByte) {
        this.cardFileByte = cardFileByte;
    }

    public String getCardFileName() {
        return cardFileName;
    }

    public void setCardFileName(String cardFileName) {
        this.cardFileName = cardFileName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月15日                     FPM0218        fnAPP19Q3001
 */
