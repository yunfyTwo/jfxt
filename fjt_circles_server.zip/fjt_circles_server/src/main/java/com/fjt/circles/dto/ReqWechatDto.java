/**
 * ReqWechatDto.java
 * Created at 2019年11月20日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>ClassName: ReqWechatDto</p>
 * <p>Description: 微信DTO</p>
 * <p>Author: Fpm0218</p>
 * <p>Date: 2019年11月20日</p>
 */
@ApiModel("微信实体")
public class ReqWechatDto extends ReqUserSupplementInfoDto {
    
    /** 申请用户类型（0:富士康采购部门员工；1:供应商员工；2:富金通员工） */
    @ApiModelProperty(value = "0:富士康采购部门员工；1:供应商员工；2:富金通员工", required = true)
    private Integer applyUserType;
    
    /** 微信头像路径 */
    @ApiModelProperty(value = "微信头像路径", required = true)
    private String wechatImgPath;

    /** 微信昵称 */
    @ApiModelProperty(value = "微信昵称", required = true)
    private String nickName;
    
    public Integer getApplyUserType() {
        return applyUserType;
    }

    public void setApplyUserType(Integer applyUserType) {
        this.applyUserType = applyUserType;
    }

    public String getWechatImgPath() {
        return wechatImgPath;
    }

    public void setWechatImgPath(String wechatImgPath) {
        this.wechatImgPath = wechatImgPath;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月20日                     FPM0218        fnAPP19Q3001
 */
