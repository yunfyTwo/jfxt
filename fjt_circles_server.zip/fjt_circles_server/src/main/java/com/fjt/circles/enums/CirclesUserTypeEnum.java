/**
 * CirclesUserTypeEnum.java
 * Created at 2019年11月18日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.enums;

import com.fjt.common.Constant;

/**
 * <p>ClassName: CirclesUserTypeEnum</p>
 * <p>Description: 用户类型枚举</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月18日</p>
 */
public enum CirclesUserTypeEnum {
    
    /** 富金通员工 */
    USER_TYPE_ZERO(0, "富金通员工"),
    
    /** 富士康采购部门员工 */
    USER_TYPE_ONE(1, "富士康采购部门员工"),
    
    /** 供应商员工 */
    USER_TYPE_TWO(2, "供应商员工");
    
    /** 键 */
    private Integer key;
    
    /** 值 */
    private String value;

    /**
     * <p>Description: 构造函数</p>
     * @param key  键
     * @param value 值
     */
    CirclesUserTypeEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }
    
    /**
     * <p>Description: 获取枚举值</p>
     * @param key 键
     * @return 返回对象
     */
    public static String getValue(Integer key) {
        for (CirclesUserTypeEnum examType : CirclesUserTypeEnum.values()) {
            if (key.equals(examType.getKey())) {
                return examType.getValue();
            }
        }
        return Constant.BLANK_STRING;
    }
    
    public Integer getKey() {
        return key;
    }

    public void setKey(Integer key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月18日                     FPM0218        fnAPP19Q3001
 */

