/**
 * CommonError.java
 * Created at 2019年11月15日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.enums;

/**
 * <p>ClassName: CommonError</p>
 * <p>Description:错误信息枚举类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月15日</p>
 */
public enum CommonError {

    /**
     * 请求失败
     */
    APP_REQUEST_ERROR("100000002", "请求失败", "request fail Error", "请求失败"),
    /**
     * 已存在
     */
    APP_EXITS_ERROR("100000003", "已存在", "exits Error", "已存在"),
    /**
     * 未知错误
     */
    APP_UNKOWN_ERROR("100000004", "未知错误", "unkown Error", "未知错误"),
    /**
     * 不存在
     */
    APP_NO_EXITS_ERROR("100000005", "不存在", "no exits Error", "不存在"),
    /**
     * 用户不存在
     */
    APP_USER_NO_EXITS_ERROR("100000006", "用户不存在", "user not exits Error", "用户不存在"),
    /**
     * 受限制
     */
    APP_PROTECT_ERROR("100000007", "访问受限制", "protect Error", "访问受限制"),
    /**
     * 密码错误
     */
    APP_PASSWORD_ERROR("100000008", "密码错误", "password Error", "密码错误"),
    /**
     * 参数不能为空
     */
    APP_PARAMETER_ERROR("100000009", "参数不能为空", "parameter Error", "参数不能为空"),
    /**
     * 未登录或者已过期，需重新登录
     */
    APP_TOKEN_EXPIRE_ERROR("100000010", "未登录或者已过期，需重新登录", "token expire Error", "未登录或者已过期，需重新登录"),
    /**
     * 无权限访问资源
     */
    APP_NO_AUTH_RESOURCES_ERROR("100000011", "无权限访问资源", "No authority Resources Error", "无权限访问资源"),
    /**
     * 没有数据
     */
    APP_NO_DATE("100000012", "没有数据", "No data Error", "没有数据"),

    /**
     * TOKEN 无效
     */
    FOCS_TOKEN_INVALID("100000013", "token 无效", "token invalid", "token 无效"),
    /**
     * 系统异常
     */
    SYSTEM_ERROR("1000000014", "系统异常,请联系客户经理", "system fail Error", "系统异常,请联系客户经理"),
    /**
     * 参数错误
     */
    APP_PARAMETER_NOT_SUPPORT("1000000015", "参数错误", "parameter Error", "参数错误");
    /**
     * 错误编码
     */
    private String errorCode;
    /**
     * 错误标题
     */
    private String errorTitle;
    /**
     * 错误信息
     */
    private String errorMsg;
    /**
     * 错误中文信息
     */
    private String errorMsgCn;

    /**
     * 构造函数
     * <p>Description: CommonError</p>
     * @param errorCode   错误编码
     * @param errorTitle  错误标题
     * @param errorMsg    错误英文描述
     * @param errorMsgCn  错误中文描述
     */
    CommonError(String errorCode, String errorTitle, String errorMsg, String errorMsgCn) {
        this.errorCode = errorCode;
        this.errorTitle = errorTitle;
        this.errorMsg = errorMsg;
        this.errorMsgCn = errorMsgCn;
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public String getErrorTitle() {
        return this.errorTitle;
    }

    public String getErrorMsg() {
        return this.errorMsg;
    }

    public String getErrorMsgCn() {
        return this.errorMsgCn;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月15日                     FPM0218        fnAPP19Q3001
 */
