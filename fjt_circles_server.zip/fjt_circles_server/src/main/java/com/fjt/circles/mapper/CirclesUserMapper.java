/**
 * CirclesUserMapper.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.mapper;

import java.util.List;
import java.util.Map;

import com.fjt.circles.domain.MyUnderPersonInfoDomain;
import com.fjt.circles.domain.UserInfoDomain;
import com.fjt.circles.model.CirclesUser;

/**
 * <p>ClassName: CirclesUserMapper</p>
 * <p>Description: 圈子用户MAPPER接口</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */
public interface CirclesUserMapper {
    
    /**
     * <p>Description: 通过用户ID获取用户信息</p>
     * @param userId 用户ID
     * @return 用户信息
     */
    public CirclesUser getCirclesUserById(Long userId);
    
    /**
     * <p>Description: 通过OPENID获取用户信息</p>
     * @param openId OPENID
     * @return 用户信息
     */
    public CirclesUser getCirclesUserByOpenId(String openId);
    
    /**
     * <p>Description: 通过用户ID获取用户信息</p>
     * @param userId 用户ID
     * @return 用户信息
     */
    public UserInfoDomain getFormatCirclesUserById(Long userId);
    
    /**
     * <p>Description: 通过OPENID获取用户信息</p>
     * @param openId OPENID
     * @return 用户信息
     */
    public UserInfoDomain getFormatCirclesUserByOpenId(String openId);
    
    /**
     * <p>Description: 获取当前自增值</p>
     * @param tableName 表名
     * @return 自增值
     */
    public Long getCurrentAutoIncrement(String tableName);
    
    /**
     * <p>Description: 保存用户信息</p>
     * @param circlesUser 用户信息
     * @return 保存数量
     */
    public Long saveCirclesUser(CirclesUser circlesUser);
    
    /**
     * <p>Description: 更新用户信息</p>
     * @param circlesUser 用户信息
     */
    public void updateCirclesUser(CirclesUser circlesUser);
    
    /**
     * <p>Description: 通过带下线的参与者查询指定类型的用户信息</p>
     * @param map 参数
     * @return 用户信息
     */
    public List<CirclesUser> getCirclesUserByParticipantAndUserType(Map<String, Object> map);
    
    /**
     * <p>Description: 通过带下线的参与者查询指定类型的用户信息总数</p>
     * @param map 参数
     * @return 用户信息总数
     */
    public Integer getCirclesUserByParticipantAndUserTypeCount(Map<String, Object> map);
    
    /**
     * <p>Description: 通过父ID获取子用户信息</p>
     * @param map 参数
     * @return 子用户信息
     */
    public List<MyUnderPersonInfoDomain> getCirclesUserByParentId(Map<String, Object> map);
    
    /**
     * <p>Description: 通过父ID获取子用户信息总数</p>
     * @param map 参数
     * @return 子用户信息总数
     */
    public Integer getCirclesUserByParentIdCount(Map<String, Object> map);

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
