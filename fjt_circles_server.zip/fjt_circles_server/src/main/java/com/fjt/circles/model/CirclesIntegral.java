/**
 * CirclesIntegral.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.model;

import java.util.Date;

/**
 * <p>ClassName: CirclesIntegral</p>
 * <p>Description: 圈子用户积分表</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */

public class CirclesIntegral {

    /** 主键 */
    private Long id;
    /** 用户ID */
    private Long circlesUserId;
    /** 贡献者ID */
    private Long contributorId;
    /** 业务类型 */
    private Integer businessType;
    /** 业务ID */
    private Long businessId;
    /** 积分 */
    private Long integral;
    /** 创建者 */
    private String createUser;
    /** 创建时间 */
    private Date createTime;
    /** 最近更新者 */
    private String lstUpdUser;
    /** 最近更新时间 */
    private Date lstUpdTime;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCirclesUserId() {
        return circlesUserId;
    }

    public void setCirclesUserId(Long circlesUserId) {
        this.circlesUserId = circlesUserId;
    }
    
    public Long getContributorId() {
        return contributorId;
    }

    public void setContributorId(Long contributorId) {
        this.contributorId = contributorId;
    }

    public Integer getBusinessType() {
        return businessType;
    }

    public void setBusinessType(Integer businessType) {
        this.businessType = businessType;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public Long getIntegral() {
        return integral;
    }

    public void setIntegral(Long integral) {
        this.integral = integral;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getLstUpdUser() {
        return lstUpdUser;
    }

    public void setLstUpdUser(String lstUpdUser) {
        this.lstUpdUser = lstUpdUser;
    }

    public Date getLstUpdTime() {
        return lstUpdTime;
    }

    public void setLstUpdTime(Date lstUpdTime) {
        this.lstUpdTime = lstUpdTime;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
