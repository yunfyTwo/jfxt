/**
 * CirclesUser.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.model;

import java.util.Date;

/**
 * <p>ClassName: CirclesUser</p>
 * <p>Description: 圈子用户表</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */
public class CirclesUser {

    /** 主键 */
    private Long id;
    /** 邀请人ID */
    private Long parentId;
    /** 源邀请人ID */
    private Long srcId;
    /** 登录账号 */
    private String openId;
    /** 工号 */
    private String serialNo;
    /** 姓名 */
    private String userName;
    /** 职务 */
    private String job;
    /** 手机 */
    private String mobile;
    /** 邮箱 */
    private String email;
    /** 申请用户类型（0:富金通员工；1:富士康采购部门员工；2:供应商员工） */
    private Integer applyUserType;
    /** 实际用户类型（null:未确认；0:确认为否；1:确认为是） */
    private Integer actualUserType;
    /** 公司名称 */
    private String companyName;
    /** 用户等级（1:普通会员；2:黄金会员） */
    private Integer userLv;
    /** 昵称 */
    private String nickName;
    /** 微信头像 */
    private String wechatImgPath;
    /** 名片 */
    private String businessCardPath;
    /** 地址 */
    private String address;
    /** 邀请链 */
    private String invitationChain;
    /** 创建者 */
    private String createUser;
    /** 创建时间 */
    private Date createTime;
    /** 最近更新者 */
    private String lstUpdUser;
    /** 最近更新时间 */
    private Date lstUpdTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Long getSrcId() {
        return srcId;
    }

    public void setSrcId(Long srcId) {
        this.srcId = srcId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getApplyUserType() {
        return applyUserType;
    }

    public void setApplyUserType(Integer applyUserType) {
        this.applyUserType = applyUserType;
    }

    public Integer getActualUserType() {
        return actualUserType;
    }

    public void setActualUserType(Integer actualUserType) {
        this.actualUserType = actualUserType;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getUserLv() {
        return userLv;
    }

    public void setUserLv(Integer userLv) {
        this.userLv = userLv;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getWechatImgPath() {
        return wechatImgPath;
    }

    public void setWechatImgPath(String wechatImgPath) {
        this.wechatImgPath = wechatImgPath;
    }

    public String getBusinessCardPath() {
        return businessCardPath;
    }

    public void setBusinessCardPath(String businessCardPath) {
        this.businessCardPath = businessCardPath;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getInvitationChain() {
        return invitationChain;
    }

    public void setInvitationChain(String invitationChain) {
        this.invitationChain = invitationChain;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getLstUpdUser() {
        return lstUpdUser;
    }

    public void setLstUpdUser(String lstUpdUser) {
        this.lstUpdUser = lstUpdUser;
    }

    public Date getLstUpdTime() {
        return lstUpdTime;
    }

    public void setLstUpdTime(Date lstUpdTime) {
        this.lstUpdTime = lstUpdTime;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
