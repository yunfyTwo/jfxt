/**
 * CirclesIntegralService.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.service;

import java.util.List;

import com.fjt.circles.domain.IntegralDateDomain;

/**
 * <p>ClassName: CirclesIntegralService</p>
 * <p>Description: 圈子用户积分接口</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */
public interface CirclesIntegralService {
    
    /**
     * <p>Description: 获取积分折线图数据</p>
     * @param userId 用户ID
     * @return 积分折线图数据
     */
    public List<IntegralDateDomain> getIntegralDiscountChart(Long userId);
    
    /**
     * <p>Description: 获取我的总积分</p>
     * @param userId 用户ID
     * @return 我的总积分
     */
    public Integer getMyTotalIntegral(Long userId);
    
    /**
     * <p>Description: 获取我贡献的总积分</p>
     * @param userId 用户ID
     * @return 我贡献的总积分
     */
    public Integer getMyContributeIntegral(Long userId);

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
