/**
 * CirclesUserService.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.service;

import java.util.Map;

import com.fjt.circles.domain.MyUnderPersonNumDomain;
import com.fjt.circles.domain.PurSupManagerDomain;
import com.fjt.circles.domain.UserInfoDomain;
import com.fjt.circles.dto.ReqUserRegDto;
import com.fjt.circles.dto.ReqUserSupplementInfoDto;
import com.fjt.circles.dto.ReqWechatDto;
import com.fjt.circles.model.CirclesUser;
import com.fjt.common.PageList;

/**
 * <p>ClassName: CirclesUserService</p>
 * <p>Description: 圈子用户接口</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */
public interface CirclesUserService {
    
    /**
     * <p>Description: 通过用户ID获取用户信息</p>
     * @param userId 用户ID
     * @return 用户信息
     */
    public UserInfoDomain getCirclesUserById(Long userId);
    
    /**
     * <p>Description: 通过OPENID获取用户信息</p>
     * @param openId OPENID
     * @return 用户信息
     */
    public Map<String, Object> getCirclesUserMapByOpenId(String openId);
    
    /**
     * <p>Description: 保存用户信息</p>
     * @param dto 用户信息
     * @return 保存结果
     */
    public Map<String, Object> saveUser(ReqUserRegDto dto);
    
    /**
     * <p>Description: 更新用户信息</p>
     * @param circlesUser 用户信息
     */
    public void updateCirclesUser(CirclesUser circlesUser);
    
    /**
     * <p>Description: 保存用户信息</p>
     * @param dto 参数
     * @return 保存结果
     */
    public String saveUserSupplementInfoInfo(ReqWechatDto dto);
    
    /**
     * <p>Description: 更新用户信息</p>
     * @param dto 参数
     * @return 更新结果
     */
    public String updateUserSupplementInfoInfo(ReqUserSupplementInfoDto dto);
    
    /**
     * <p>Description: 获取我参与邀请的供应商</p>
     * @param id 用户ID
     * @param currentPage 当前页
     * @param pageSize 页面大小
     * @return 我参与邀请的供应商
     */
    public PageList getMyInvitedSupplier(Long id, int currentPage, int pageSize); 
    
    /**
     * <p>Description: 获取我的下线人数</p>
     * @param userId 用户ID
     * @return 下线人数
     */
    public MyUnderPersonNumDomain getMyUnderUserCountByParentId(Long userId);
    
    /**
     * <p>Description: 获取我的下线人员详情</p>
     * @param userId 用户ID
     * @param currentPage 当前页
     * @param pageSize 页面大小
     * @return 下线人员详情
     */
    public PageList getMyUnderUserByParentId(Long userId, int currentPage, int pageSize); 
    
    /**
     * <p>Description: 获取采购商和客户经理信息</p>
     * @param userId 用户ID
     * @return 采购商和客户经理信息
     */
    public PurSupManagerDomain getPurAndManagerInfo(Long userId);

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
