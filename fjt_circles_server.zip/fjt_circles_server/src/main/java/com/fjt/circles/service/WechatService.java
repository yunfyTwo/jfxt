/**
 * WechatService.java
 * Created at 2019年11月15日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.service;

/**
 * <p>ClassName: WechatService</p>
 * <p>Description: 微信调用接口</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月15日</p>
 */
public interface WechatService {
    
    /**
     * <p>Description: 通过JSCODE获取OPENID</p>
     * @param jsCode JSCODE
     * @return OPENID
     */
    public String getOpenId(String jsCode);

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月15日                     FPM0218        fnAPP19Q3001
 */
