/**
 * CirclesIntegralServiceImpl.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fjt.circles.domain.IntegralDateDomain;
import com.fjt.circles.mapper.CirclesIntegralMapper;
import com.fjt.circles.service.CirclesIntegralService;
import com.fjt.core.utils.DateUtils;

/**
 * <p>ClassName: CirclesIntegralServiceImpl</p>
 * <p>Description: 圈子用户积分接口实现</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */
@Service
public class CirclesIntegralServiceImpl implements CirclesIntegralService {
    
    /**
     * 积分接口
     */
    @Autowired
    private CirclesIntegralMapper circlesIntegralMapper;
    
    @Override
    public List<IntegralDateDomain> getIntegralDiscountChart(Long userId) {
        List<IntegralDateDomain> listDomain = new ArrayList<IntegralDateDomain>();
        //获取积分折线图数据
        List<IntegralDateDomain> list = circlesIntegralMapper.getIntegralDiscountChart(userId);
        //当前时间的前六个月数组
        String[] dateArr = DateUtils.getLastSixMonthArr();
        //遍历当前时间的前六个月数组和折线图数据，当折线图数据中不存在前六个月的数组之中，则积分设置为0
        for (int i = 0 ; i < dateArr.length; i++) {
            IntegralDateDomain domain = new IntegralDateDomain();
            domain.setCreateTime(dateArr[i]);
            domain.setIntegral(0);
            for (IntegralDateDomain idd : list) {
                if (dateArr[i].equals(idd.getCreateTime())) {
                    domain.setIntegral(idd.getIntegral());
                    break;
                }
            }
            listDomain.add(domain);
        } 
        return listDomain;
    }
    
    @Override
    public Integer getMyTotalIntegral(Long userId) {
        return circlesIntegralMapper.getMyTotalIntegral(userId);
    }
    
    @Override
    public Integer getMyContributeIntegral(Long userId) {
        return circlesIntegralMapper.getMyContributeIntegral(userId);
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
