/**
 * CirclesUserServiceImpl.java
 * Created at 2019年11月12日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;

import com.fjt.circles.domain.MyUnderPersonInfoDomain;
import com.fjt.circles.domain.MyUnderPersonNumDomain;
import com.fjt.circles.domain.PurSupDomain;
import com.fjt.circles.domain.PurSupManagerDomain;
import com.fjt.circles.domain.UserInfoDomain;
import com.fjt.circles.dto.ReqUserRegDto;
import com.fjt.circles.dto.ReqUserSupplementInfoDto;
import com.fjt.circles.dto.ReqWechatDto;
import com.fjt.circles.enums.CirclesUserTypeEnum;
import com.fjt.circles.enums.CommonError;
import com.fjt.circles.mapper.CirclesUserMapper;
import com.fjt.circles.model.CirclesUser;
import com.fjt.circles.service.CirclesUserService;
import com.fjt.circles.service.WechatService;
import com.fjt.common.Constant;
import com.fjt.common.DateUtil;
import com.fjt.common.PageList;
import com.fjt.common.StringUtil;
import com.fjt.core.utils.SftpClientUtils;

/**
 * <p>ClassName: CirclesUserServiceImpl</p>
 * <p>Description: 圈子用户接口实现</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月12日</p>
 */
@Service
public class CirclesUserServiceImpl implements CirclesUserService {
    
    /** 日志 */
    private static final Logger LOGGER = LoggerFactory.getLogger(CirclesUserServiceImpl.class);
    
    /** 圈子用户表 */
    private static final String CIRCLES_USER = "circles_user";
    
    /** 正斜线 */
    private static final String FORWARD_SLASH = "/";
    
    /** 短横线 */
    private static final String SHORT_TRANSVERSE_LINE = "-";
    
    /**
     * 用户MAPPER接口
     */
    @Autowired
    private CirclesUserMapper circlesUserMapper;
    
    /**
     * 微信接口
     */
    @Autowired
    private WechatService wechatService;
    
    @Cacheable(value = "circlesUserId")
    @Override
    public UserInfoDomain getCirclesUserById(Long userId) {
        UserInfoDomain domain = circlesUserMapper.getFormatCirclesUserById(userId);
        domain.setBusinessCardPath(SftpClientUtils.fomatFilePath(domain.getBusinessCardPath()));
        return domain;
    }
    
    @Cacheable(value = "circlesUserMapOpenId")
    @Override
    public Map<String, Object> getCirclesUserMapByOpenId(String openId) {
        Map<String, Object> map = new HashMap<String, Object>();
        UserInfoDomain userInfoDomain = circlesUserMapper.getFormatCirclesUserByOpenId(openId);
        if (userInfoDomain == null) {
            return map;
        }
        userInfoDomain.setBusinessCardPath(SftpClientUtils.fomatFilePath(userInfoDomain.getBusinessCardPath()));
        map.put("currentUser", userInfoDomain);
        if (userInfoDomain.getParentUserId() != null && userInfoDomain.getParentUserId() > 0) {
            UserInfoDomain domain = circlesUserMapper.getFormatCirclesUserById(userInfoDomain.getParentUserId());
            domain.setBusinessCardPath(SftpClientUtils.fomatFilePath(domain.getBusinessCardPath()));
            map.put("inviter", domain);
        }
        return map;
    }
    
    @Override
    @Transactional
    public Map<String, Object> saveUser(ReqUserRegDto dto) {
        Map<String, Object> map = new HashMap<String, Object>();
        CirclesUser parentUser = null;
        if (StringUtil.isNotEmpty(dto.getInviterId())) {
            Long inviterId = Long.valueOf(StringUtil.decode(dto.getInviterId()));
            //查询邀请者信息
            parentUser = circlesUserMapper.getCirclesUserById(inviterId);
            if (parentUser == null) {
                String errorMsg = "inviterId无效";
                LOGGER.info(errorMsg);
                map.put("errorMsg", errorMsg);
                return map;
            }
        }
        String jsCode = dto.getJsCode();
        String openId = wechatService.getOpenId(jsCode);
        if (Constant.BLANK_STRING.equals(openId)) {
            String errorMsg = "jsCode为:" + jsCode + "的请求没有对应的openId（jsCode无效）";
            LOGGER.info(errorMsg);
            map.put("errorMsg", errorMsg);
            return map;
        }
        map = getCirclesUserMapByOpenId(openId);
        if (map.isEmpty()) {
            Long id = circlesUserMapper.getCurrentAutoIncrement(CIRCLES_USER);
            CirclesUser newUser = new CirclesUser();
            newUser.setOpenId(openId);
            Date now = new Date();
            newUser.setLstUpdTime(now);
            newUser.setCreateTime(now);
            newUser.setUserLv(1);
            //无邀请人
            if (parentUser == null) {
                newUser.setSrcId(id);
                newUser.setInvitationChain(String.valueOf(id));
            } else {
                //存在邀请人
                newUser.setParentId(parentUser.getId());
                newUser.setSrcId(parentUser.getSrcId());
                newUser.setInvitationChain(parentUser.getInvitationChain() + SHORT_TRANSVERSE_LINE + id);
            }
            circlesUserMapper.saveCirclesUser(newUser);
            map = getCirclesUserMapByOpenId(openId);
        }
        return map;
    }
    
    @Override
    public void updateCirclesUser(CirclesUser circlesUser) {
        circlesUserMapper.updateCirclesUser(circlesUser);
    }
    
    @Override
    @Transactional
    public String saveUserSupplementInfoInfo(ReqWechatDto dto) {
        return updateUserInfo(dto);
    }
    
    @Override
    @Transactional
    public String updateUserSupplementInfoInfo(ReqUserSupplementInfoDto dto) {
        ReqWechatDto wechatDto = new ReqWechatDto();
        BeanUtils.copyProperties(dto, wechatDto);
        return updateUserInfo(wechatDto);
    }
    
    @Override
    public PageList getMyInvitedSupplier(Long id, int currentPage, int pageSize) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("participant", id);
        map.put("userType", Constant.TWO);
        //查询记录总数
        int totalCount = circlesUserMapper.getCirclesUserByParticipantAndUserTypeCount(map);
        PageList pageList = new PageList(totalCount, pageSize, currentPage);
        currentPage = (currentPage - 1) * pageSize;
        map.put("startRows", currentPage);
        map.put("pageSize", pageSize);
        //查询参与链的供应商信息
        List<CirclesUser> list = circlesUserMapper.getCirclesUserByParticipantAndUserType(map);
        if (list.isEmpty()) {
            return null; 
        }
        //封装采供商和供应商信息
        List<PurSupDomain> listPurSupDomain = getPurSupDomain(list);
        pageList.setDataList(listPurSupDomain);
        return pageList;
    }
    
    
    @Override
    public MyUnderPersonNumDomain getMyUnderUserCountByParentId(Long userId) {
        MyUnderPersonNumDomain domain = new MyUnderPersonNumDomain();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("userId", userId);
        //查询我的所有下线
        List<MyUnderPersonInfoDomain> list = circlesUserMapper.getCirclesUserByParentId(map);
        if (list.isEmpty()) {
            return domain;
        }
        domain.setInviteTotal(list.size());
        List<MyUnderPersonInfoDomain> listUnConfirm = list.stream().filter(cu -> 
            Constant.BLANK_STRING.equals(cu.getActualUserType())).collect(Collectors.toList());
        int unConfirm = 0;
        if (!listUnConfirm.isEmpty()) {
            unConfirm = listUnConfirm.size();
            domain.setUnConfirmCount(unConfirm);
        }
        domain.setConfirmCount(list.size() - unConfirm);
        return domain;
    }
    
    @Override
    public PageList getMyUnderUserByParentId(Long userId, int currentPage, int pageSize) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("userId", userId);
        //查询记录总数
        int totalCount = circlesUserMapper.getCirclesUserByParentIdCount(map);
        PageList pageList = new PageList(totalCount, pageSize, currentPage);
        currentPage = (currentPage - 1) * pageSize;
        map.put("startRows", currentPage);
        map.put("pageSize", pageSize);
        List<MyUnderPersonInfoDomain> list = circlesUserMapper.getCirclesUserByParentId(map);
        pageList.setDataList(list);
        return pageList;
    }
    
    @Override
    public PurSupManagerDomain getPurAndManagerInfo(Long userId) {
        PurSupManagerDomain domain = new PurSupManagerDomain();
        CirclesUser supCirclesUser = circlesUserMapper.getCirclesUserById(userId);
        if (supCirclesUser != null) {
            domain.setSupNickName(supCirclesUser.getNickName());
            domain.setSupWechatImgPath(supCirclesUser.getWechatImgPath());
            if (supCirclesUser.getParentId() != null) {
                //获取上游最相近的采购商
                CirclesUser purCirclesUser = getLastUserByType(supCirclesUser.getParentId(), CirclesUserTypeEnum.USER_TYPE_ONE.getKey());
                CirclesUser mangerCirclesUser = null;
                //存在上游采购商
                if (purCirclesUser != null) {
                    domain.setPurNickName(purCirclesUser.getNickName());
                    domain.setPurWechatImgPath(purCirclesUser.getWechatImgPath());
                    //获取采购商上游最相近的客户经理
                    mangerCirclesUser = getLastUserByType(purCirclesUser.getParentId(), CirclesUserTypeEnum.USER_TYPE_ZERO.getKey());
                } else {
                    //不存在上游采购商、则获取供应商上游最相近的客户经理
                    mangerCirclesUser = getLastUserByType(supCirclesUser.getParentId(), CirclesUserTypeEnum.USER_TYPE_ZERO.getKey());
                }
                //存在客户经理则设置
                if (mangerCirclesUser != null) {
                    domain.setManagerNickName(mangerCirclesUser.getNickName());
                    domain.setManagerWechatImgPath(mangerCirclesUser.getWechatImgPath());
                    domain.setManagerBusinessCardPath(SftpClientUtils.fomatFilePath(mangerCirclesUser.getBusinessCardPath()));
                } 
            }
        }
        return domain;
    }
    
    /**
     * <p>Description: 更新用户信息</p>
     * @param dto 参数
     * @return 更新结果
     */
    private String updateUserInfo(ReqWechatDto dto) {
        Long userId = dto.getUserId();
        //查询当前登录客户是否已存在
        CirclesUser circlesUser = circlesUserMapper.getCirclesUserById(userId);
        //不存在
        if (circlesUser == null) {
            return CommonError.APP_USER_NO_EXITS_ERROR.getErrorTitle();
        }
        String remoteDir = "businessCard" + FORWARD_SLASH + circlesUser.getId() + FORWARD_SLASH + DateUtil.getDateYmd(new Date());
        //文件路径
        String cardFilePath = uploadFile(dto.getCardFileName(), dto.getCardFileByte(), remoteDir);
        if (CommonError.SYSTEM_ERROR.getErrorTitle().equals(cardFilePath)) {
            return CommonError.SYSTEM_ERROR.getErrorTitle();
        }
        Date now = new Date();
        circlesUser.setLstUpdTime(now);
        circlesUser.setLstUpdUser(String.valueOf(userId));
        circlesUser.setUserName(dto.getUserName());
        circlesUser.setJob(dto.getJob());
        circlesUser.setMobile(dto.getMobile());
        circlesUser.setEmail(dto.getEmail());
        circlesUser.setAddress(dto.getAddress());
        circlesUser.setCompanyName(dto.getCompanyName());
        circlesUser.setBusinessCardPath(cardFilePath);
        //若微信路径为空，则表示只更新用户的名片信息
        if (StringUtil.isNotEmpty(dto.getWechatImgPath())) {
            circlesUser.setApplyUserType(dto.getApplyUserType());
            circlesUser.setWechatImgPath(dto.getWechatImgPath());
            circlesUser.setNickName(dto.getNickName());
        }
        circlesUserMapper.updateCirclesUser(circlesUser);
        return Constant.YES;
    }

    /**
     * <p>Description: 上传文件</p>
     * @param originalFileName 图片名
     * @param fileByte 文件流
     * @param remoteDir 存储路径
     * @return 文件路径
     */
    private String uploadFile(String originalFileName, byte[] fileByte, String remoteDir) {
        //文件路径
        String filePath = Constant.BLANK_STRING;
        //若存在名片,则上传
        if (StringUtil.isNotEmpty(originalFileName)) {
            try {
                //图片后缀名
                String suffix = originalFileName.substring(originalFileName.lastIndexOf(Constant.HALF_CORNER_EN_POINT));
                //图片服务器文件名
                String fileName = StringUtil.getUuid() + suffix;
                filePath = remoteDir + FORWARD_SLASH + fileName;
                SftpClientUtils.upload(fileByte, fileName, remoteDir);
            } catch (Throwable e) {
                LOGGER.info("文件上传失败");
                return CommonError.SYSTEM_ERROR.getErrorTitle();
            }
        }
        return filePath;
    }
    
    /**
     * <p>Description: 封装采供商和供应商信息</p>
     * @param listCirclesUser 供应商信息
     * @return 采供商和供应商信息
     */
    private List<PurSupDomain> getPurSupDomain(List<CirclesUser> listCirclesUser) {
        List<PurSupDomain> list = new ArrayList<PurSupDomain>();
        PurSupDomain purSupDomain = new PurSupDomain();
        //遍历供应商
        for (CirclesUser circlesUser : listCirclesUser) {
            if (circlesUser == null || circlesUser.getParentId() == null) {
                break;
            }
            //查询供应商上游最相近的采购商
            CirclesUser parentUser = getLastUserByType(circlesUser.getParentId(), CirclesUserTypeEnum.USER_TYPE_ONE.getKey());
            if (parentUser != null) {
                purSupDomain.setSupNickName(circlesUser.getNickName());
                purSupDomain.setSupUserType(2);
                purSupDomain.setSupWechatImgPath(circlesUser.getWechatImgPath());
                purSupDomain.setPurUserType(1);
                purSupDomain.setPurNickName(parentUser.getNickName());
                purSupDomain.setPurWechatImgPath(parentUser.getWechatImgPath());
                list.add(purSupDomain);
            }
        }
        return list;
    }
    
    /**
     * <p>Description: 递归上游最相近的用户类型</p>
     * @param userId 用户ID
     * @param userType 用户类型
     * @return 上游最相近的用户类型
     */
    private CirclesUser getLastUserByType(Long userId, Integer userType) {
        CirclesUser circlesUser = circlesUserMapper.getCirclesUserById(userId);
        if (circlesUser == null || circlesUser.getApplyUserType() == userType) {
            return circlesUser;
        }
        if (circlesUser.getParentId() == null) {
            return null;
        }
        return getLastUserByType(circlesUser.getParentId(), userType);
    }
    

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月12日                     FPM0218        fnAPP19Q3001
 */
