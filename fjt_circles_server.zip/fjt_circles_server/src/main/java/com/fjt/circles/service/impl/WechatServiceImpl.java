/**
 * WechatServiceImpl.java
 * Created at 2019年11月15日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.circles.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.fjt.circles.service.WechatService;
import com.fjt.common.Constant;
import com.fjt.common.HttpClientUtil;
import com.fjt.common.StringUtil;
import com.fjt.core.utils.WechatConfigUtils;

/**
 * <p>ClassName: WechatServiceImpl</p>
 * <p>Description: 微信调用接口实现类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月15日</p>
 */
@Service
public class WechatServiceImpl implements WechatService {
    
    /** 日志 */
    private static final Logger LOGGER = LoggerFactory.getLogger(WechatServiceImpl.class);
    
    @Override
    public String getOpenId(String jsCode) {
        String url =  "https://api.weixin.qq.com/sns/jscode2session?appid=" + WechatConfigUtils.getWechatAppId() + "&secret=" 
                + WechatConfigUtils.getWechatAppSecret() + "&js_code=" + jsCode + "&grant_type=authorization_code";
        LOGGER.debug("jsCode=" + jsCode + "，发送请求：" + url);
        String result = HttpClientUtil.sendGetRequest(url, null);
        LOGGER.debug("jsCode=" + jsCode + "的查询结果" + result);
        String json = result.substring(result.indexOf("{"), result.indexOf("}")) + "}";
        if (StringUtil.isEmpty(json)) {
            return Constant.BLANK_STRING;
        }
        JSONObject jsonObject = JSONObject.parseObject(json);
        return StringUtil.isEmpty((String) jsonObject.get("openid")) ? Constant.BLANK_STRING : (String) jsonObject.get("openid");
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月15日                     FPM0218        fnAPP19Q3001
 */
