/**
 * ExcludeFromComponentScan.java
 * Created at 2018年5月22日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */
package com.fjt.core.annotation;

/**
 * <p>ClassName: ExcludeFromComponentScan</p>
 * <p>Description: 不扫描注解</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年5月22日</p>
 */
public @interface ExcludeFromComponentScan {

}

/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
