/**
 * DruidDataSourceConfig.java
 * Created at 2018年4月20日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */

package com.fjt.core.configuration;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;
import com.fjt.common.StringUtil;

/**
 * <p>ClassName: DruidDataSourceConfig</p>
 * <p>Description: DruidDataSourceConfig</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年4月20日</p>
 */
@Configuration
public class DruidDataSourceConfig {
    /**
     * 
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DruidDataSourceConfig.class);
    /**
     * 数据源配置的前缀
     */
    private static final String DS_PREFIX = "spring.datasource";

    /**
     * <p>Description: FilterRegistrationBean</p>
     * @return FilterRegistrationBean
     */
    @Bean
    public FilterRegistrationBean filterRegistrationBean() {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean(new WebStatFilter());
        filterRegistrationBean.addUrlPatterns("/*");
        filterRegistrationBean.addInitParameter("exclusions", "*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*");
        return filterRegistrationBean;
    }

    /**
     * <p>Description: ServletRegistrationBean</p>
     * @return ServletRegistrationBean
     */
    @Bean
    public ServletRegistrationBean druidServlet() {
        ServletRegistrationBean servletRegistrationBean = new ServletRegistrationBean();
        servletRegistrationBean.setServlet(new StatViewServlet());
        servletRegistrationBean.addUrlMappings("/druid/*");
        Map<String, String> initParameters = new HashMap<String, String>();
        initParameters.put("loginUsername", "druid"); // 用户名  
        initParameters.put("loginPassword", "druid"); // 密码  
        initParameters.put("resetEnable", "false"); // 禁用HTML页面上的“Reset All”功能  
        initParameters.put("allow", "127.0.0.1"); // IP白名单 (没有配置或者为空，则允许所有访问)  
        // initParameters.put("deny", "192.168.20.38");// IP黑名单   (存在共同时，deny优先于allow) 
        servletRegistrationBean.setInitParameters(initParameters);
        return servletRegistrationBean;
    }

    /**
     * <p>ClassName: IDataSourceProperties</p>
     * <p>Description: 配置文件对应类，解决 spring.datasource.filters=stat,wall,log4j 无法正常注册进去</p>
     * <p>Author: FPM0302</p>
     * <p>Date: 2018年4月24日</p>
     */
    @ConfigurationProperties(prefix = DS_PREFIX)
    class DataSourceProperties {
        /**
         * 
         */
        private String url;
        /**
         * 
         */
        private String username;
        /**
         * 
         */
        private String password;
        /**
         * 
         */
        private String driverClassName;
        /**
         * 
         */
        private int initialSize;
        /**
         * 
         */
        private int minIdle;
        /**
         * 
         */
        private int maxActive;
        /**
         * 
         */
        private int maxWait;
        /**
         * 
         */
        private int timeBetweenEvictionRunsMillis;
        /**
         * 
         */
        private int minEvictableIdleTimeMillis;
        /**
         * 
         */
        private String validationQuery;
        /**
         * 
         */
        private Boolean testWhileIdle;
        /**
         * 
         */
        private Boolean testOnBorrow;
        /**
         * 
         */
        private Boolean testOnReturn;
        /**
         * 
         */
        private Boolean poolPreparedStatements;
        /**
         * 
         */
        private int maxPoolPreparedStatementPerConnectionSize;
        /**
         * 
         */
        private String filters;
        /**
         * 
         */
        private String connectionProperties;

        /**
         * <p>Description: DataSource</p>
         * @return DataSource
         */
        @Bean
        @Primary
        public DataSource dataSource() {
            DruidDataSource datasource = new DruidDataSource();
            datasource.setUrl(this.url);
            datasource.setUsername(username);
            datasource.setPassword(password);
            datasource.setDriverClassName(driverClassName);

            //下面连接池的补充设置
            if (this.initialSize > 0) {
                datasource.setInitialSize(initialSize);
            }
            if (this.minIdle > 0) {
                datasource.setMinIdle(minIdle);
            }
            if (this.maxActive > 0) {
                datasource.setMaxActive(maxActive);
            }
            if (this.maxWait > 0) {
                datasource.setMaxWait(maxWait);
            }
            if (this.timeBetweenEvictionRunsMillis > 0) {
                datasource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
            }
            if (this.minEvictableIdleTimeMillis > 0) {
                datasource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
            }
            if (!StringUtil.isEmpty(validationQuery)) {
                datasource.setValidationQuery(validationQuery);
            }
            if (this.testWhileIdle != null) {
                datasource.setTestWhileIdle(testWhileIdle);
            }
            if (this.testOnBorrow != null) {
                datasource.setTestOnBorrow(testOnBorrow);
            }
            if (this.testOnReturn != null) {
                datasource.setTestOnReturn(testOnReturn);
            }
            if (this.poolPreparedStatements != null) {
                datasource.setPoolPreparedStatements(poolPreparedStatements);
            }
            if (maxPoolPreparedStatementPerConnectionSize > 0) {
                datasource.setMaxPoolPreparedStatementPerConnectionSize(maxPoolPreparedStatementPerConnectionSize);
            }
            try {
                if (!StringUtil.isEmpty(filters)) {
                    datasource.setFilters(filters);
                }
            } catch (SQLException e) {
                LOGGER.error("druid configuration initialization filter: " + e);
            }
            if (!StringUtil.isEmpty(connectionProperties)) {
                datasource.setConnectionProperties(connectionProperties);
            }
            return datasource;
        }

        public String getUrl() {
            return this.url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getUsername() {
            return this.username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return this.password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getDriverClassName() {
            return this.driverClassName;
        }

        public void setDriverClassName(String driverClassName) {
            this.driverClassName = driverClassName;
        }

        public int getInitialSize() {
            return this.initialSize;
        }

        public void setInitialSize(int initialSize) {
            this.initialSize = initialSize;
        }

        public int getMinIdle() {
            return this.minIdle;
        }

        public void setMinIdle(int minIdle) {
            this.minIdle = minIdle;
        }

        public int getMaxActive() {
            return this.maxActive;
        }

        public void setMaxActive(int maxActive) {
            this.maxActive = maxActive;
        }

        public int getMaxWait() {
            return this.maxWait;
        }

        public void setMaxWait(int maxWait) {
            this.maxWait = maxWait;
        }

        public int getTimeBetweenEvictionRunsMillis() {
            return this.timeBetweenEvictionRunsMillis;
        }

        public void setTimeBetweenEvictionRunsMillis(int timeBetweenEvictionRunsMillis) {
            this.timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
        }

        public int getMinEvictableIdleTimeMillis() {
            return this.minEvictableIdleTimeMillis;
        }

        public void setMinEvictableIdleTimeMillis(int minEvictableIdleTimeMillis) {
            this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
        }

        public String getValidationQuery() {
            return this.validationQuery;
        }

        public void setValidationQuery(String validationQuery) {
            this.validationQuery = validationQuery;
        }

        public boolean isTestWhileIdle() {
            return this.testWhileIdle;
        }

        public void setTestWhileIdle(boolean testWhileIdle) {
            this.testWhileIdle = testWhileIdle;
        }

        public boolean isTestOnBorrow() {
            return this.testOnBorrow;
        }
        public void setTestOnBorrow(boolean testOnBorrow) {
            this.testOnBorrow = testOnBorrow;
        }

        public boolean isTestOnReturn() {
            return this.testOnReturn;
        }

        public void setTestOnReturn(boolean testOnReturn) {
            this.testOnReturn = testOnReturn;
        }

        public int getMaxPoolPreparedStatementPerConnectionSize() {
            return this.maxPoolPreparedStatementPerConnectionSize;
        }

        public void setMaxPoolPreparedStatementPerConnectionSize(int maxPoolPreparedStatementPerConnectionSize) {
            this.maxPoolPreparedStatementPerConnectionSize = maxPoolPreparedStatementPerConnectionSize;
        }

        public String getFilters() {
            return this.filters;
        }

        public void setFilters(String filters) {
            this.filters = filters;
        }

        public String getConnectionProperties() {
            return this.connectionProperties;
        }

        public void setConnectionProperties(String connectionProperties) {
            this.connectionProperties = connectionProperties;
        }

        public boolean isPoolPreparedStatements() {
            return this.poolPreparedStatements;
        }

        public void setPoolPreparedStatements(boolean poolPreparedStatements) {
            this.poolPreparedStatements = poolPreparedStatements;
        }

    }

}

/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
