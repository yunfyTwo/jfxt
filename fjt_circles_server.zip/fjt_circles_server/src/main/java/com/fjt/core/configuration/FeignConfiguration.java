/**
 * FeignDisableHystrixConfiguration.java
 * Created at 2018年5月9日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */
package com.fjt.core.configuration;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fjt.core.annotation.ExcludeFromComponentScan;

import feign.RequestInterceptor;
import feign.RequestTemplate;

/**
 * <p>ClassName: FeignDisableHystrixConfiguration</p>
 * <p>Description: 全局feign 拦截</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年5月9日</p>
 */
@Configuration
@ExcludeFromComponentScan
public class FeignConfiguration implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate requestTemplate) {
        Enumeration<String> headerNames = null;
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = null;
        if (null != requestAttributes) {
            ServletRequestAttributes attributes = (ServletRequestAttributes) requestAttributes;
            request = attributes.getRequest();
            headerNames = request.getHeaderNames();
        }
        if (headerNames != null) {
            while (headerNames.hasMoreElements()) {
                String name = headerNames.nextElement();
                String values = request.getHeader(name);
                requestTemplate.header(name, values);
            }
        }
    }
 
  
}

/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
