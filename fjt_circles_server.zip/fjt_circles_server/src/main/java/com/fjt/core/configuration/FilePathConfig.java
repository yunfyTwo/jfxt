/**
 * FilePathConfig.java
 * Created at 2019年11月20日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.core.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fjt.core.utils.SftpClientUtils;

/**
 * <p>ClassName: FilePathConfig</p>
 * <p>Description: 文件访问路径配置类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月20日</p>
 */
@Configuration
public class FilePathConfig {
    
    /** 文件路径 */
    @Value("${filepath}")
    private String filePath;
    
    /** 文件访问路径 */
    @Value("${filevisitpath}")
    private String fileVisitPath;
    
    /**
     * <p>Description: 加载文件路径配置</p>
     * @return 文件路径实体工具
     */
    @Bean
    public SftpClientUtils setFilePath() {
        return new SftpClientUtils(filePath, fileVisitPath);
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月20日                     FPM0218        fnAPP19Q3001
 */
