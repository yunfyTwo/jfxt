/**
 * JwtConfig.java
 * Created at 2018年4月28日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */

package com.fjt.core.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fjt.common.JwtTokenUtil;
import com.fjt.common.JwtUser;
import com.fjt.common.JwtUserList;
import com.fjt.common.StringUtil;

/**
 * <p>ClassName: JwtConfig</p>
 * <p>Description: JwtConfig 配置类</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年4月28日</p>
 */
@Configuration
public class JwtConfig {
    /**
     * 注入 grantApps
     */
    @Value("${security.grantApps}")
    private String grantApps;
    /**
     * 加密的盐值
     */
    @Value("${security.jwt.sercetKey}")
    private String sercetKey;
    
    /**
     * Jwt 时长，秒
     */
    @Value("${security.jwt.tokenTimeout:3600}")
    private long tokenTimeout;
    
    @Bean
    public JwtTokenUtil getJwtTokenUtil() {
        return new JwtTokenUtil(this.sercetKey, this.tokenTimeout);
    }
    /**
     * <p>Description: 得到用户列表对象</p>
     * @return JwtUserList
     */
    @Bean
    public JwtUserList getJwtUserList() {
        JwtUserList jwtUserList = new JwtUserList();
        //解析appid:appsecuriyID:ip
        if (!StringUtil.isEmpty(this.grantApps)) {
            String[] resultVals = this.grantApps.split(",");
            if (resultVals == null || resultVals.length == 0) {
                return jwtUserList;
            }
            for (String resultVal : resultVals) {
                String[] app = resultVal.split(":");
                if (app == null || app.length != 3) {
                    continue;
                }
                JwtUser jwtUser = new JwtUser();
                jwtUser.setAppKey(app[0]);
                jwtUser.setAppSecret(app[1]);
                if (app[2] != null && app[2].length() > 0) {
                    String[] whiteIpList = app[2].split("-");
                    for (String whiteIp : whiteIpList) {
                        jwtUser.getWhiteIpList().add(whiteIp);
                    }
                }
                jwtUserList.getUserMap().put(app[0], jwtUser);
            }
        }

        return jwtUserList;
    }
    
}

/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
