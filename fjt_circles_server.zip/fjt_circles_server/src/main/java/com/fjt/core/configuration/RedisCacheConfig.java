/**
 * RedisCacheConfig.java
 * Created at 2018年4月25日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */
package com.fjt.core.configuration;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.util.ClassUtils;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fjt.common.RedisService;
import com.fjt.common.StringUtil;

import redis.clients.jedis.JedisPoolConfig;

/**
 * <p>ClassName: RedisCacheConfig</p>
 * <p>Description: RedisCacheConfig</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年4月25日</p>
 */
@Configuration
public class RedisCacheConfig extends CachingConfigurerSupport {
    /**
     * NO_PARAM_KEY
     */
    public static final int NO_PARAM_KEY = 0;
    /**
     * NULL_PARAM_KEY
     */
    public static final int NULL_PARAM_KEY = 53;
    /**
     * redis 缺省的过期时间
     */
    @Value("${spring.cache.redis.defaultExpireTime:300}")
    private long defaultExpireTime;
    /**
     * 配置好的缓存对象以及过期时间
     */
    @Value("${spring.cache.redis.caches:'default:30000'}")
    private String caches;
    /**
     * 获取应用的名称，用于产生redis的key
     */
    @Value("${spring.application.name:'applicationname'}")
    private String applicationName;
    
    /**
     * host
     */
    @Value("${spring.redis.host:'127.0.0.1'}")
    private String hostName;
    /**
     * port
     */
    @Value("${spring.redis.port:6379}")
    private int port;
    /**
     * password
     */
    @Value("${spring.redis.password:''}")
    private String passWord;
    /**
     * database
     */
    @Value("${spring.redis.database:0}")
    private int database;
    /**
     * timeout
     */
    @Value("${spring.redis.timeout:2000}")
    private int timeout;
    
    /**
     * maxidle
     */
    @Value("${spring.redis.pool.max-idle:8}")
    private int maxIdl;
    /**
     * minIdl
     */
    @Value("${spring.redis.pool.min-idle:0}")
    private int minIdl;
    
    /**
     * testOnBorrow
     */
    @Value("${spring.redis.pool.testOnBorrow:true}")
    private boolean testOnBorrow;
    /**
     * <p>Description: RedisConnectionFactory</p>
     * @return RedisConnectionFactory
     */
    @Bean
    public RedisConnectionFactory jedisConnectionFactory() {
        JedisPoolConfig poolConfig = new JedisPoolConfig();
        poolConfig.setMaxIdle(maxIdl);
        poolConfig.setMinIdle(minIdl);
        poolConfig.setTestOnBorrow(testOnBorrow);
        poolConfig.setTestOnReturn(true);
        poolConfig.setTestWhileIdle(false);
        poolConfig.setNumTestsPerEvictionRun(10);
        poolConfig.setTimeBetweenEvictionRunsMillis(60000);
        JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(poolConfig);
        jedisConnectionFactory.setTimeout(timeout);
        jedisConnectionFactory.setHostName(hostName); 
        if (!passWord.isEmpty()) { 
            jedisConnectionFactory.setPassword(passWord); 
        } 
        jedisConnectionFactory.setPort(port); 
        jedisConnectionFactory.setDatabase(database);
        return jedisConnectionFactory;
    }
    /**
     * <p>Description: RedisTemplate Bean</p>
     * @return RedisTemplate
     */
    @Bean
    public RedisTemplate<?, ?> redisTemplate() {
        RedisTemplate<?, ?> template = new StringRedisTemplate();
        template.setConnectionFactory(jedisConnectionFactory());
        @SuppressWarnings({ "rawtypes", "unchecked" })
        Jackson2JsonRedisSerializer jacksonToJsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);
        ObjectMapper om = new ObjectMapper();
        om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        jacksonToJsonRedisSerializer.setObjectMapper(om);
        template.setHashValueSerializer(jacksonToJsonRedisSerializer);
        template.setKeySerializer(jacksonToJsonRedisSerializer);
        template.setValueSerializer(jacksonToJsonRedisSerializer);
        template.setHashKeySerializer(jacksonToJsonRedisSerializer);

        template.afterPropertiesSet();
        return template;
    }
    /**
     * <p>Description: RedisService</p>
     * @param redisTemplate RedisTemplate<String, Object>
     * @return RedisService
     */
    @Bean
    public RedisService getRedisService(RedisTemplate<String, Object> redisTemplate) {
        return new RedisService(redisTemplate);
    }

    /**
     * <p>Description: 该CacheManager 用于Spring Boot1.x</p>
     * @param redisTemplate RedisTemplate
     * @return CacheManager
     */
    @Bean
    public CacheManager cacheManager(RedisTemplate<?, ?> redisTemplate) {
        RedisCacheManager cacheManager = new RedisCacheManager(redisTemplate);
        Map<String, Long> expires = new HashMap<String, Long>();
        if (!StringUtil.isEmpty(this.caches)) {
            String[] cacheList = this.caches.split(",");
            for (String cache : cacheList) {
                String[] cacheItems = cache.split(":");
                if (cacheItems != null && cacheItems.length == 2) {
                    try {
                        long ttl = Long.parseLong(cacheItems[1]);
                        expires.put(cacheItems[0], ttl);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        continue;
                    }
                }
            }
        }
        cacheManager.setExpires(expires);
        cacheManager.setDefaultExpiration(this.defaultExpireTime); //设置key-value超时时间
        return cacheManager;
    }

    /**
     * 下面的方法实用于Spring boot2.0以后
     */
    /*
     * @Bean(name = "cacheManager")
     * @Primary public CacheManager cacheManager(ObjectMapper objectMapper,
     * RedisConnectionFactory redisConnectionFactory) {
     * Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new
     * Jackson2JsonRedisSerializer(Object.class); ObjectMapper om = new
     * ObjectMapper(); om.setVisibility(PropertyAccessor.ALL,
     * JsonAutoDetect.Visibility.ANY);
     * om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
     * jackson2JsonRedisSerializer.setObjectMapper(om);
     * @SuppressWarnings("unchecked") RedisCacheConfiguration
     * cacheDefaultConfiguration = RedisCacheConfiguration.defaultCacheConfig()
     * .entryTtl(Duration.ofSeconds(defaultExpireTime))
     * .disableCachingNullValues()
     * .serializeKeysWith(RedisSerializationContext.SerializationPair.
     * fromSerializer(new StringRedisSerializer())) .serializeValuesWith(
     * RedisSerializationContext .SerializationPair
     * .fromSerializer(jackson2JsonRedisSerializer)); Map<String,
     * RedisCacheConfiguration> cacheConfigurations = new HashMap<String,
     * RedisCacheConfiguration>(); if(!StringUtil.isEmpty(caches)) { String []
     * cacheList =caches.split(","); for (String cache : cacheList) { String []
     * cacheItems =cache.split(":"); if(cacheItems != null &&
     * cacheItems.length==2) { try { long ttl = Long.parseLong(cacheItems[1]);
     * @SuppressWarnings("unchecked") RedisCacheConfiguration cacheConfiguration
     * = RedisCacheConfiguration.defaultCacheConfig()
     * .entryTtl(Duration.ofSeconds(ttl)) .disableCachingNullValues()
     * .serializeKeysWith(RedisSerializationContext.SerializationPair.
     * fromSerializer(new StringRedisSerializer())) .serializeValuesWith(
     * RedisSerializationContext .SerializationPair
     * .fromSerializer(jackson2JsonRedisSerializer));
     * cacheConfigurations.put(cacheItems[0], cacheConfiguration); } catch
     * (NumberFormatException e) { e.printStackTrace(); continue; } } } } return
     * RedisCacheManager.builder(redisConnectionFactory)
     * .cacheDefaults(cacheDefaultConfiguration)
     * .withInitialCacheConfigurations(cacheConfigurations) .build(); }
     */

    @Bean
    @Override
    public KeyGenerator keyGenerator() {
        return new KeyGenerator() {
            @Override
            public Object generate(Object target, Method method, Object... params) {
                StringBuilder key = new StringBuilder();
                key.append(applicationName);
                key.append(target.getClass().getName()).append(".");
                key.append(method.getName()).append(":");
                for (Object param : params) {
                    if (param == null) {
                        key.append(NULL_PARAM_KEY);
                    } else if (ClassUtils.isPrimitiveArray(param.getClass())) {
                        int length = Array.getLength(param);
                        for (int i = 0; i < length; i++) {
                            key.append(Array.get(param, i));
                            key.append(',');
                        }
                    } else if (ClassUtils.isPrimitiveOrWrapper(param.getClass()) || param instanceof String) {
                        key.append(param);
                    } else {
                        key.append(param.hashCode());
                    }
                    key.append('-');
                }
                return key.toString();
            }
        };
    }
}

/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version Date Author Note
 * ------------------------------------------------------------------------- 1.0.0
 * 1.0.0 2018年06月11日 fpm0302 initializtion
 * 
 */
