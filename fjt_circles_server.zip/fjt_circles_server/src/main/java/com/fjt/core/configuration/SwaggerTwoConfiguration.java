/**
 * SwaggerTwo.java
 * Created at 2018年7月9日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */
package com.fjt.core.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fjt.common.BusinessConstants;

import io.swagger.annotations.ApiOperation;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * <p>ClassName: SwaggerTwoConfiguration</p>
 * <p>Description: Swagger2的配置文件</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年7月9日</p>
 */

@Configuration
@EnableSwagger2
public class SwaggerTwoConfiguration {
    
    /**
     * 是否开启swagger
     */
    @Value("${swagger.enable:false}")
    private boolean swaggerEnable ;
    /**
     * host:IP:端口地址
     */
    @Value("${swagger.swaggerUrl}")
    private String swaggerUrl;
    /**
     * <p>Description: Docket</p>
     * @return Docket
     */
    @Bean
    public Docket createRestApi() {
        ParameterBuilder paramBuilder = new ParameterBuilder();
        List<Parameter> pars = new ArrayList<Parameter>();
        paramBuilder.name(BusinessConstants.Token.TOKEN_KEY)
                    .description("用户令牌")
                    .modelRef(new ModelRef("string"))
                    .parameterType("header")
                    .required(false);
        pars.add(paramBuilder.build());
        /*paramBuilder.name("isEncrpt").description("是否加密").modelRef(new ModelRef("boolean")).parameterType("header").required(false)
                .defaultValue("false");
        pars.add(paramBuilder.build());*/
        return new Docket(DocumentationType.SWAGGER_2)
                .host(swaggerUrl)
                .apiInfo(apiInfo())
                .enable(swaggerEnable) //是否启用
                .select()
                //为当前包路径
                .apis(RequestHandlerSelectors.basePackage("com.fjt.circles.controller"))  //扫描的包
                .apis(RequestHandlerSelectors.withMethodAnnotation(ApiOperation.class)) //只有ApiOperation 这个注解才显示
                //.paths(PathSelectors.regex("/.*/api/.*")) //只有包含 api的路径才显示
                .paths(PathSelectors.any())
                .build()
                .globalOperationParameters(pars) ; //全局的请求头
    }
    /**
     * <p>Description: ApiInfo</p>
     * @return ApiInfo
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                //页面标题
                .title("Spring Boot 使用 Swagger2 构建RESTful API")
                //.termsOfServiceUrl("") 网址链接
                //创建人
                .contact(new Contact("FJT", "http://www.fjt.com/", "400-660-0970"))
                //版本号
                .version("1.0")
                //描述
                .description("API 描述")
                .build();
    }
}
