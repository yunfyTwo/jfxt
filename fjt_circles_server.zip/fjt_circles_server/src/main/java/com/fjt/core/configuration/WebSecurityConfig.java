/**
 * WebSecurityConfig.java
 * Created at 2018年5月2日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */
package com.fjt.core.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.fjt.common.StringUtil;
import com.fjt.core.interceptor.AuthorizeInterceptor;

/**
 * <p>ClassName: WebSecurityConfig</p>
 * <p>Description: WebMvc 的配置类</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年5月2日</p>
 */
@Configuration
public class WebSecurityConfig extends WebMvcConfigurerAdapter {
    /**
     * 不做拦截的url
     */
    @Value("${security.permitUrls}")
    private String permitUrls;

    @Bean
    public AuthorizeInterceptor getAuthorizeInterceptor() {
        return new AuthorizeInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        InterceptorRegistration addInterceptor = registry.addInterceptor(getAuthorizeInterceptor());
        // 排除配置
        //addInterceptor.excludePathPatterns("/error/**");
        //addInterceptor.excludePathPatterns("/sign/**");
        if (!StringUtil.isEmpty(this.permitUrls)) {
            String[] permitUrlList = this.permitUrls.split(",");
            if (permitUrlList != null && permitUrlList.length > 0) {
                for (String permitUrl : permitUrlList) {
                    addInterceptor.excludePathPatterns(permitUrl);
                }
            }
        }
        // 拦截配置
        addInterceptor.addPathPatterns("/**");
    }
}


/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
