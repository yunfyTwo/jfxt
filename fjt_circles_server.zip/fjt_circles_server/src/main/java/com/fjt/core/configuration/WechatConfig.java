/**
 * WechatConfig.java
 * Created at 2019年11月15日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.core.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fjt.core.utils.WechatConfigUtils;

/**
 * <p>ClassName: WechatConfig</p>
 * <p>Description: 加载微信配置</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月15日</p>
 */
@Configuration
public class WechatConfig {
    
    /** APPID */
    @Value("${wechat.appid}")
    private String wechatAppId;
    
    /** APPSECRET */
    @Value("${wechat.appsecret}")
    private String wechatAppSecret;
    
    /** 邀请地址 */
    @Value("${wechat.inviteUrl}")
    private String inviteUrl;
    
    /**
     * <p>Description: 加载微信配置</p>
     * @return 微信实体工具
     */
    @Bean
    public WechatConfigUtils setWechatConfig() {
        return new WechatConfigUtils(wechatAppId, wechatAppSecret, inviteUrl);
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月15日                     FPM0218        fnAPP19Q3001
 */
