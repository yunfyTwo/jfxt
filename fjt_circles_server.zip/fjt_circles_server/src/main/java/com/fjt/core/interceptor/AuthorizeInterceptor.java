/**
 * AuthorizeInterceptor.java
 * Created at 2018年5月2日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */
package com.fjt.core.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.fjt.common.BusinessConstants;
import com.fjt.common.HttpClientUtil;
import com.fjt.common.JsonUtil;
import com.fjt.common.ResponseData;
import com.fjt.common.StringUtil;
import com.fjt.core.token.TokenComponent;

/**
 * <p>ClassName: AuthorizeInterceptor</p>
 * <p>Description: AuthorizeInterceptor token 权限校验拦截器</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年5月2日</p>
 */
public class AuthorizeInterceptor implements HandlerInterceptor {

    /**
     * TokenSignService
     */
    @Autowired
    private TokenComponent tokenComponent;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        ResponseData exceptionData = new ResponseData();
        String method = request.getMethod();
        HttpClientUtil.setHeader(request, response);
        if ("OPTIONS".equalsIgnoreCase(method)) {
            return false;
        }
        String token = request.getHeader(BusinessConstants.Token.TOKEN_KEY);
        boolean checkAuth = true;
        if (!StringUtil.isEmpty(token)) {
            String requestIp = HttpClientUtil.getIpAddr(request);
            checkAuth = this.tokenComponent.checkToken(token, requestIp);
        } else {
            checkAuth = false;
            exceptionData.setCode(-3);
            exceptionData.setMessage("没有获取到token");
        }
        if (checkAuth) {
            return true;
        }
        //401 没有授权
        exceptionData.setHttpStatus(HttpStatus.UNAUTHORIZED.value());
        //403 已经登录，但是没有权限访问
        //exceptionData.setHttpStatus(HttpServletResponse.SC_FORBIDDEN);
        //exceptionData.setMessage("请登录后使用该系统");
        String returnData = JsonUtil.objectToJson(exceptionData);
        HttpClientUtil.responseOutJson(response, returnData);
        return false;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }

}

/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
