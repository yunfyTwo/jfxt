/**
 * GlobalExceptionHandler.java
 * Created at 2018年4月25日
 * Created by FPM0302
 * Copyright (C) 2014-2018 FNConn, All rights reserved.
 */
package com.fjt.core.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.fjt.common.BusinessException;
import com.fjt.common.ExceptionUtil;
import com.fjt.common.ResponseCode;
import com.fjt.common.ResponseData;

/**
 * <p>ClassName: GlobalExceptionHandler</p>
 * <p>Description: 统一异常处理</p>
 * <p>Author: FPM0302</p>
 * <p>Date: 2018年4月25日</p>
 */
@RestControllerAdvice
public class GlobalExceptionHandler {
    /**
     * Logger
     */
    private final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * 
     * <p>Description: 异常拦截</p>
     * @param ex Exception 拦截
     * @return 返回数据
     */
    @ExceptionHandler(value = Exception.class)
    public ResponseData handler(Exception ex) {
        ResponseData responseData = new ResponseData();
        this.logger.error("统一异常处理", ex);
        responseData.setCode(-1);

        if (ex instanceof BusinessException) {
            BusinessException businessException = (BusinessException) ex;
            responseData.setMessage(businessException.getMessage());
            responseData.setCode(businessException.getCode());
        } else {
            responseData.setMessage(ResponseCode.UNKNOWN_ERROR.getMessage() + ExceptionUtil.getExceptionDetail(ex));
            responseData.setCode(-1);
        }
        return responseData;
    }
}


/**

* Revision History

* -------------------------------------------------------------------------

* Version       Date             Author          Note

* -------------------------------------------------------------------------

* 1.0.0     2018年06月11日                FPM0302         initializtion

*/
