/**
 * TokenComponent.java
 * Created at 2019年10月13日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.core.token;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fjt.common.BusinessException;
import com.fjt.common.JwtTokenUtil;
import com.fjt.common.JwtUserList;
import com.fjt.common.StringUtil;

/**
 * <p>ClassName: TokenComponent</p>
 * <p>Description: TOKEN组件</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月13日</p>
 */
@Component
public class TokenComponent {
    
    /**
     * JwtTokenUtil
     */
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    
    /**
     * JwtUserList
     */
    @Autowired
    private JwtUserList jwtUserList;

    /**
     * <p>Description: getToken</p>
     * @param appKey appKey
     * @param appSecurity appSecurity
     * @param ip ip
     * @return token 值
     */
    public String getToken(String appKey, String appSecurity, String ip) {
        String token = null;
        boolean isCheckOk = checkTokenInfo(appKey, appSecurity, ip, true);
        if (isCheckOk) {
            token = this.jwtTokenUtil.generateToken(appKey, null, null);
        }
        return token;
    }

    /**
     * <p>Description: 核对chenk检查项信息</p>
     * @param appKey appKey
     * @param appSecurity appSecurity
     * @param ip  ip
     * @param checkAppSec 是否需要检查 appSecurity 这个值
     * @return 是否成功
     */
    public boolean checkTokenInfo(String appKey, String appSecurity, String ip, boolean checkAppSec) {
        boolean isOk = false;
        //判断appKey是否 存在
        if (StringUtil.isEmpty(appKey) || StringUtil.isEmpty(ip) || !this.jwtUserList.getUserMap().containsKey(appKey)) {
            throw new BusinessException("无效账号", -1);
        }
        if (checkAppSec) {
            //appSecurity = MdFiveUtil.mdFive(appSecurity);
            if (!appSecurity.equals(this.jwtUserList.getUserMap().get(appKey).getAppSecret())) {
                throw new BusinessException("无效账号", -1);
            }
        }
        //判断是否白名单
        if (!this.jwtUserList.getUserMap().get(appKey).containIp(ip)) {
            throw new BusinessException("非法访问地址", -2);
        }
        isOk = true;
        return isOk;
    }

    /**
     * <p>Description: 校验Token是否合法，以及是否授权的IP</p>
     * @param token token
     * @param requestIp 请求者的IP
     * @return 是否合法
     */
    public boolean checkToken(String token, String requestIp) {
        boolean isOk = false;
        Claims claims = null;
        try {
            claims = this.jwtTokenUtil.verifyToken(token);
            //请求的key是否存在
            String key = claims.getId();
            isOk = checkTokenInfo(key, null, requestIp, false);
            //可以结合redis做进一步的功能扩展
        } catch (ExpiredJwtException e) {
            throw new BusinessException("token过期", -3);
        } catch (BusinessException e) {
            throw e;
        }
        return isOk;
    }
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月13日                     FPM0218        fnAPP19Q3001
 */
