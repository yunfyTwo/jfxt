/**
 * DateUtils.java
 * Created at 2019年11月19日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.core.utils;

import java.util.Calendar;

import com.fjt.common.Constant;

/**
 * <p>ClassName: DateUtils</p>
 * <p>Description: 时间工具类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月19日</p>
 */
public class DateUtils {
    
    /**
     * <p>Description: 获取最近六个月组成的数据数组</p>
     * @return 最近六个月组成的数据数组
     */
    public static String[] getLastSixMonthArr() {
        Calendar calendar = Calendar.getInstance();
        int lastMonth = calendar.get(Calendar.MONTH);
        int currentYear = calendar.get(Calendar.YEAR);
        String[] dateArr = new String[6];
        for (int i = 0; i < 6; i++) {
            int month = lastMonth - i;
            int year = currentYear;
            if (month <= 0) {
                year = currentYear - 1;
                month += 12; 
            }
            dateArr[i] = year + "-" + (month < 10 ? Constant.ZERO + month : month);
        }
        return dateArr;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月19日                     FPM0218        fnAPP19Q3001
 */
