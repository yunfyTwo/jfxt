/**
 * PageList.java
 * Created at 2019年11月18日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.core.utils;

import java.util.List;

/**
 * <p>ClassName: PageList</p>
 * <p>Description: PageList对象</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月18日</p>
 */
public class PageList implements java.io.Serializable {
    /**
     * <p>Field serialVersionUID: 序列化</p>
     */
    private static final long serialVersionUID = 54656546231546L;
    /**
     * 分页结果集
     */
    private List<Object> dataList = null;
    /**
     * 记录总数
     */
    private int totalcount = 0;
    /**
     * 每页显示记录数
     */
    private int pageSize = 0;
    /**
     * 当前页数
     */
    private int currentPage = 1;
    /**
     * 总页数
     */
    private int totalPageCount = 1;
    
    /**
     * 默认行数
     */
    private final int ten = 10;

    /**
     * <p>Description: 初始化分页组件 </p>
     * @param totalcount 记录总数
     * @param pageSize  每页显示记录数
     * @param currentPage 当前页数
     */
    public PageList(int totalcount, int pageSize, int currentPage) {
        setTotalcount(totalcount);
        setPageSize(pageSize);
        setCurrentPage(currentPage);
    }

    /**
     * <p>Description: 设置当前页数及每页条数</p>
     * @param pageSize 每页显示记录数
     * @param currentPage 当前页数
     */
    public PageList(int pageSize, int currentPage) {
        setPageSize(pageSize);
        setCurrentPage(currentPage);
    }

    /**
     * <p>Description: 更新当前页数</p>
     */
    public void updateIndex() {
        totalPageCount = getTotalPageCount();
        if (currentPage > totalPageCount) {
            currentPage = totalPageCount;
        } else if (currentPage < 1) {
            currentPage = 1;
        }
    }

    public List<Object> getDataList() {
        return dataList;
    }

    public void setDataList(List<Object> dataList) {
        this.dataList = dataList;
    }

    public int getTotalcount() {
        return totalcount;
    }

    public void setTotalcount(int totalcount) {
        this.totalcount = totalcount;
    }

    public int getPageSize() {
        return pageSize <= 0 ? ten : pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getCurrentPage() {
        return currentPage <= 0 ? 1 : currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    /**
     * <p>Description: 获取总页数</p>
     * @return 总页数
     */
    public int getTotalPageCount() {
        int p = 0;
        if (totalcount % pageSize == 0) {
            p = totalcount / pageSize;
        } else {
            p = totalcount / pageSize + 1;
        }
        return p == 0 ? 1 : p;
    }

    public void setTotalPageCount(int totalPageCount) {
        this.totalPageCount = totalPageCount;
    }
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月18日                     FPM0218        fnAPP19Q3001
 */
