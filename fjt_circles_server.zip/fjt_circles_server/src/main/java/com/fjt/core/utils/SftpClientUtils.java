/**
 * SftpClientUtils.java
 * Created at 2019年11月13日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.core.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fjt.common.StringUtil;

/**
 * <p>ClassName: SftpClientUtils</p>
 * <p>Description: SFTP工具类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月13日</p>
 */
public class SftpClientUtils {
    
    /** 日志 */
    private static final Logger LOGGER = LoggerFactory.getLogger(SftpClientUtils.class);
    
    /** 文件路径 */
    private static String filePath;
    
    /** 文件访问路径 */
    private static String fileVisitPath;
    
    /**
     * 构造函数
     * @param filePath 文件路径
     * @param fileVisitPath 文件访问路径
     */
    public SftpClientUtils(String filePath, String fileVisitPath) {
        SftpClientUtils.setFilePath(filePath);
        SftpClientUtils.setFileVisitPath(fileVisitPath);
    }
    
    public static String getFilePath() {
        return filePath;
    }

    public static void setFilePath(String filePath) {
        SftpClientUtils.filePath = filePath;
    }
    
    public static String getFileVisitPath() {
        return fileVisitPath;
    }

    public static void setFileVisitPath(String fileVisitPath) {
        SftpClientUtils.fileVisitPath = fileVisitPath;
    }

    /**
     * <p>Description: 上传文件</p>
     * @param fileByte 文件流 
     * @param fileName 文件名
     * @param remoteDir 远程目录
     * @return 上传结果
     */
    public static boolean upload(byte[] fileByte, String fileName, String remoteDir) {
        try {
            String dir = dealRemoteDir(filePath) + remoteDir;
            File file = new File(dir);
            if (!file.exists()) {
                file.mkdirs();
            }
            String pathUrl = dealRemoteDir(dir) + fileName;
            LOGGER.info("文件上传路径:" + pathUrl);
            File targetFile = new File(pathUrl);
            FileUtils.copyInputStreamToFile(new ByteArrayInputStream(fileByte), targetFile);
            return true;
        } catch (IOException e1) {
            e1.printStackTrace();
            return false;
        }
    }
    
    /**
     * <p>Description: 获取文件流</p>
     * @param path 文件路径
     * @return 文件流
     */
    public static byte[] access(String path) {
        path =  dealRemoteDir(filePath) + path;
        return access(new File(path));
    }
    
    /**
     * <p>Description: 获取文件流</p>
     * @param file 文件
     * @return 文件流
     */
    private static byte[] access(File file) {
        if (!file.exists()) {
            return null;
        }
        byte[] buffer = null;
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return buffer;
    }
    
    /**
     * <p>Description: 远程文件目录格式化</p>
     * @param remoteDir 远程文件目录
     * @return 远程文件目录格式化结果
     */
    public static String dealRemoteDir(String remoteDir) {
        StringBuffer buffer = new StringBuffer(remoteDir);
        String fileSeparator = "/";
        if (!remoteDir.endsWith(fileSeparator)) {
            buffer = buffer.append(fileSeparator);
        }
        return buffer.toString();
    }

    /**
     * <p>Description: 格式化文件路径</p>
     * @param path 文件路径
     * @return 格式化后的文件路径
     */
    public static String fomatFilePath(String path) {
        if (StringUtil.isNotEmpty(path)) {
            return dealRemoteDir(fileVisitPath) + path;
        }
        return path;
    }
    
}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月13日                     FPM0218        fnAPP19Q3001
 */
