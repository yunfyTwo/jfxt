/**
 * WechatConfigUtils.java
 * Created at 2019年11月15日
 * Created by FPM0218
 * Copyright (C) 2014-2019 FNConn, All rights reserved.
 */
package com.fjt.core.utils;

/**
 * <p>ClassName: WechatConfigUtils</p>
 * <p>Description: 微信配置工具类</p>
 * <p>Author: FPM0218</p>
 * <p>Date: 2019年11月15日</p>
 */
public class WechatConfigUtils {
    
    /** 微信APPID */
    private static String wechatAppId;
    
    /** 微信APPSECRET */
    private static String wechatAppSecret;
    
    /** 邀请地址 */
    private static String inviteUrl;
    
    /**
     * 构造函数
     * @param wechatAppId 微信APPID
     * @param wechatAppSecret 微信APPSECRET
     * @param inviteUrl 邀请地址
     */
    public WechatConfigUtils(String wechatAppId, String wechatAppSecret, String inviteUrl) {
        WechatConfigUtils.setWechatAppId(wechatAppId);
        WechatConfigUtils.setWechatAppSecret(wechatAppSecret);
        WechatConfigUtils.setInviteUrl(inviteUrl);
    }

    public static String getWechatAppId() {
        return wechatAppId;
    }

    public static void setWechatAppId(String wechatAppId) {
        WechatConfigUtils.wechatAppId = wechatAppId;
    }

    public static String getWechatAppSecret() {
        return wechatAppSecret;
    }

    public static void setWechatAppSecret(String wechatAppSecret) {
        WechatConfigUtils.wechatAppSecret = wechatAppSecret;
    }

    public static String getInviteUrl() {
        return inviteUrl;
    }

    public static void setInviteUrl(String inviteUrl) {
        WechatConfigUtils.inviteUrl = inviteUrl;
    }

}
/**
 * Revision History
 * -------------------------------------------------------------------------
 * Version       Date             Author          Note
 * -------------------------------------------------------------------------
 * 1.1.0     2019年11月15日                     FPM0218        fnAPP19Q3001
 */
